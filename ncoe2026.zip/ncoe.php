<?php
/**
 * 成都舜王科技有限公司 - 站群综合管理系统
 * 版本：1.5
 * 功能：站群配置、文件管理、友情链接管理、批量替换、DNSPod域名解析、打包备份、自删除等
 * 更新：友情链接使用说明内联显示（不弹出新页面）、ncoe压缩包支持直接下载、备份管理操作结果置顶
 */

// 错误报告开启，便于调试
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 会话支持
if (!isset($_SESSION)) {
    session_start();
}

// ==================== 全局常量定义 ====================
define('DNSPOD_ID', '602027');
define('DNSPOD_TOKEN', '42cee404806861341a06e1e1277b46d2');
define('API_URL', 'https://dnsapi.cn');

// 三段式文件夹正则（宽松匹配，支持三段和四段）
$folderPattern = '/^([a-zA-Z0-9]+)-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)$/i';
// 四段式正则（用于 www 开头的特殊情况）
$folderPattern4 = '/^(www)-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)$/i';

// 目标文件列表（用于备份管理扫描）
$target_files = ['bp.php', 'ftp.php', 'ncoe.php', 'seo.html', '.htaccess', 'down.php', 'seo_keywords_mapping.txt'];

// 当前目录
$currentDir = getcwd();

// ==================== 通用函数 ====================

// 递归删除目录
function deleteDirectory($dir) {
    if (!file_exists($dir)) return true;
    if (!is_dir($dir)) return unlink($dir);
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') continue;
        if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) return false;
    }
    return rmdir($dir);
}

// 格式化文件大小
function formatFileSize($size) {
    $units = array('B', 'KB', 'MB', 'GB');
    $i = 0;
    while ($size >= 1024 && $i < 3) { $size /= 1024; $i++; }
    return round($size, 2) . ' ' . $units[$i];
}

// 安全路径检查
function isSafePath($path, $baseDir) {
    $realBase = realpath($baseDir);
    $realPath = realpath($path);
    if ($realPath === false || strpos($realPath, $realBase) !== 0) return false;
    return true;
}

// 获取相对路径
function getRelativePath($path, $baseDir) {
    $baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    if (strpos($path, $baseDir) === 0) return substr($path, strlen($baseDir));
    return $path;
}

// 获取文件对应的域名URL
function getFileDomainUrl($filePath, $baseDir) {
    global $folderPattern, $folderPattern4;
    $relativePath = getRelativePath($filePath, $baseDir);
    // 四段式文件夹内文件
    if (preg_match('/^(www)-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)\/(.+)$/', $relativePath, $matches)) {
        $subdomain = 'www.' . $matches[2] . '.' . $matches[3] . '.' . $matches[4];
        $fileName = $matches[5];
        return 'http://' . $subdomain . '/' . $fileName;
    }
    // 三段式文件夹内文件
    if (preg_match('/^([a-zA-Z0-9]+)-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)\/(.+)$/', $relativePath, $matches)) {
        $subdomain = $matches[1] . '.' . $matches[2] . '.' . $matches[3];
        $fileName = $matches[4];
        return 'http://' . $subdomain . '/' . $fileName;
    }
    // 四段式文件夹本身
    if (preg_match($folderPattern4, $relativePath, $matches)) {
        $subdomain = 'www.' . $matches[2] . '.' . $matches[3] . '.' . $matches[4];
        return 'http://' . $subdomain . '/';
    }
    // 三段式文件夹本身
    if (preg_match($folderPattern, $relativePath, $matches)) {
        $subdomain = $matches[1] . '.' . $matches[2] . '.' . $matches[3];
        return 'http://' . $subdomain . '/';
    }
    if (in_array(basename($filePath), array('.htaccess', 'ncoe.php', 'ftp.php'))) {
        return 'http://' . $_SERVER['HTTP_HOST'] . '/' . basename($filePath);
    }
    return '';
}

// 检测域名DNS
function checkDomainDNS($domain) {
    $result = array('ip' => array(), 'cname' => array(), 'error' => '');
    $ipRecords = @dns_get_record($domain, DNS_A);
    if ($ipRecords) foreach ($ipRecords as $record) if (isset($record['ip'])) $result['ip'][] = $record['ip'];
    $cnameRecords = @dns_get_record($domain, DNS_CNAME);
    if ($cnameRecords) foreach ($cnameRecords as $record) if (isset($record['target'])) $result['cname'][] = $record['target'];
    if (empty($result['ip']) && empty($result['cname'])) $result['error'] = '未找到DNS解析记录';
    return $result;
}

// SEO关键词映射文件
function getSeoMappingFile() { return 'seo_keywords_mapping.txt'; }
function readSeoMapping() {
    $mapping = array();
    if (file_exists(getSeoMappingFile())) {
        $lines = explode("\n", file_get_contents(getSeoMappingFile()));
        foreach ($lines as $line) {
            $line = trim($line);
            if (!empty($line)) {
                $parts = explode('|', $line);
                if (count($parts) >= 2) $mapping[trim($parts[0])] = trim($parts[1]);
            }
        }
    }
    return $mapping;
}
function saveSeoMapping($mapping) {
    $content = '';
    foreach ($mapping as $domain => $keyword) $content .= $domain . '|' . $keyword . "\n";
    return file_put_contents(getSeoMappingFile(), $content);
}

// 递归添加文件夹到ZIP
function addFolderToZip($folder, $zip, $base_path = '') {
    $files = scandir($folder);
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;
        $file_path = $folder . '/' . $file;
        $zip_path = $base_path . '/' . $file;
        if (is_dir($file_path)) {
            $zip->addEmptyDir($zip_path);
            addFolderToZip($file_path, $zip, $zip_path);
        } else {
            $zip->addFile($file_path, $zip_path);
        }
    }
}

// 扫描目录（用于备份管理）- 支持三段和四段
function scanDirectories($target_files) {
    global $folderPattern, $folderPattern4;
    $folders = [];
    $target_files_found = [];
    $ncoe_zips = [];
    $items = scandir('.');
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item === basename(__FILE__)) continue;
        if (is_dir($item) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) {
            $folder_info = ['name' => $item, 'files' => []];
            foreach ($target_files as $file) {
                $folder_info['files'][$file] = file_exists($item . '/' . $file);
            }
            $folders[] = $folder_info;
        }
        if (is_file($item) && in_array($item, $target_files)) {
            $target_files_found[] = $item;
        }
        if (is_file($item) && preg_match('/^ncoe.*\.zip$/i', $item)) {
            $ncoe_zips[] = $item;
        }
    }
    return ['folders' => $folders, 'target_files' => $target_files_found, 'ncoe_zips' => $ncoe_zips];
}

// 打包文件夹和文件
function packFoldersAndFiles($folders, $target_files, $ncoe_zips) {
    if (!class_exists('ZipArchive')) {
        return ['success' => false, 'error' => '服务器未启用 ZipArchive 扩展'];
    }
    $zip = new ZipArchive();
    $filename = 'ncoe_' . date('Y-m-d_H-i-s') . '.zip';
    if ($zip->open($filename, ZipArchive::CREATE) !== TRUE) {
        return ['success' => false, 'error' => '无法创建ZIP文件'];
    }
    foreach ($folders as $folder) {
        $folder_name = $folder['name'];
        $zip->addEmptyDir($folder_name);
        addFolderToZip($folder_name, $zip, $folder_name);
    }
    foreach ($target_files as $file) {
        if (file_exists($file)) $zip->addFile($file, $file);
    }
    foreach ($ncoe_zips as $zip_file) {
        if (file_exists($zip_file)) $zip->addFile($zip_file, $zip_file);
    }
    if ($zip->close()) return ['success' => true, 'filename' => $filename];
    else return ['success' => false, 'error' => 'ZIP文件关闭失败'];
}

// 清空所有检测到的文件夹、文件和压缩包
function clearAll($folders, $target_files, $ncoe_zips) {
    $deleted_folders = 0; $deleted_files = 0; $deleted_zips = 0; $errors = [];
    foreach ($folders as $folder) {
        if (deleteDirectory($folder['name'])) $deleted_folders++;
        else $errors[] = "删除文件夹失败: {$folder['name']}";
    }
    foreach ($target_files as $file) {
        if ($file === basename(__FILE__)) continue;
        if (file_exists($file) && unlink($file)) $deleted_files++;
        else $errors[] = "删除文件失败: $file";
    }
    foreach ($ncoe_zips as $zip_file) {
        if (file_exists($zip_file) && unlink($zip_file)) $deleted_zips++;
        else $errors[] = "删除压缩包失败: $zip_file";
    }
    $message = "清空完成：删除了 $deleted_folders 个文件夹、$deleted_files 个文件和 $deleted_zips 个压缩包";
    $remaining_files = array_diff(scandir('.'), ['.', '..', basename(__FILE__)]);
    if (empty($remaining_files)) {
        $message .= "\n\n✅ 所有文件和文件夹已成功删除！\n\n现在您可以安全地手动删除 " . basename(__FILE__) . " 文件，或者使用自删除脚本。";
    } else {
        $remaining_count = count($remaining_files);
        $message .= "\n\n📝 注意：当前目录中还有 {$remaining_count} 个文件/文件夹未被删除，包括当前脚本文件 (" . basename(__FILE__) . ")。";
    }
    if (empty($errors)) return ['success' => true, 'message' => $message];
    else return ['success' => false, 'error' => implode('; ', $errors)];
}

// 创建自删除脚本
function createSelfDeleteScript() {
    $self_delete_script = 'delete_self.php';
    $script_content = '<?php
$main_script = "' . basename(__FILE__) . '";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    header("Content-Type: application/json");
    if (isset($_POST["delete_main_script"])) {
        if (file_exists($main_script)) {
            if (unlink($main_script)) echo json_encode(["success" => true, "message" => "✅ 主脚本文件删除成功"]);
            else echo json_encode(["success" => false, "message" => "❌ 主脚本文件删除失败"]);
        } else echo json_encode(["success" => true, "message" => "⚠️ 主脚本文件不存在"]);
        exit;
    }
    if (isset($_POST["delete_self_script"])) {
        if (unlink(__FILE__)) echo json_encode(["success" => true, "message" => "✅ 自删除脚本删除成功"]);
        else echo json_encode(["success" => false, "message" => "❌ 自删除脚本删除失败"]);
        exit;
    }
}
?><!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>脚本自删除工具</title><style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:Arial;background:linear-gradient(135deg,#667eea,#764ba2);min-height:100vh;display:flex;justify-content:center;align-items:center;}.container{background:white;border-radius:15px;padding:40px;max-width:500px;text-align:center;}.btn{background:#3182ce;color:white;border:none;padding:12px 24px;border-radius:6px;cursor:pointer;margin:5px;}.btn-close{background:#e53e3e;}</style></head>
<body><div class="container"><h2>🧹 脚本自删除工具</h2><div id="status">准备删除...</div><button class="btn btn-close" onclick="window.close()">关闭</button></div>
<script>
fetch("",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"delete_main_script=true"}).then(r=>r.json()).then(d=>{document.getElementById("status").innerHTML=d.message;setTimeout(()=>{fetch("",{method:"POST",body:"delete_self_script=true"}).then(r=>r.json()).then(d2=>{document.getElementById("status").innerHTML+="<br>"+d2.message;setTimeout(()=>window.close(),3000);});},1000);});
</script></body></html>';
    if (file_put_contents($self_delete_script, $script_content)) {
        return ['success' => true, 'message' => "自删除脚本创建成功！", 'script_url' => $self_delete_script];
    } else {
        return ['success' => false, 'error' => '创建自删除脚本失败'];
    }
}

// ==================== DNSPod 类 ====================
class DnspodManager {
    private $id; private $token;
    public function __construct($id, $token) { $this->id = $id; $this->token = $token; }
    private function makeRequest($endpoint, $data = array()) {
        $url = API_URL . '/' . $endpoint;
        $postData = array_merge(array('login_token' => $this->id . ',' . $this->token, 'format' => 'json', 'lang' => 'cn', 'error_on_empty' => 'no'), $data);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_USERAGENT, 'DNSPod Sync Tool/1.0.0');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_error($ch)) throw new Exception("cURL错误: " . curl_error($ch));
        curl_close($ch);
        if ($httpCode !== 200) throw new Exception("API请求失败: HTTP " . $httpCode);
        $result = json_decode($response, true);
        if (!isset($result['status']) || $result['status']['code'] !== '1') {
            $errorMsg = isset($result['status']['message']) ? $result['status']['message'] : '未知错误';
            throw new Exception("API错误: " . $errorMsg);
        }
        return $result;
    }
    public function getDomainList() { $result = $this->makeRequest('Domain.List'); return isset($result['domains']) ? $result['domains'] : array(); }
    public function getDomainInfo($domain) { return $this->makeRequest('Domain.Info', array('domain' => $domain)); }
    public function listRecords($domain, $subDomain = null) { $data = array('domain' => $domain); if ($subDomain) $data['sub_domain'] = $subDomain; $result = $this->makeRequest('Record.List', $data); return isset($result['records']) ? $result['records'] : array(); }
    public function createRecord($domain, $subDomain, $recordType, $value, $ttl = 600, $line = '默认') { $data = array('domain' => $domain, 'sub_domain' => $subDomain, 'record_type' => $recordType, 'value' => $value, 'ttl' => strval($ttl), 'record_line' => $line); return $this->makeRequest('Record.Create', $data); }
    public function modifyRecord($domain, $recordId, $subDomain, $recordType, $value, $ttl = 600, $line = '默认') { $data = array('domain' => $domain, 'record_id' => $recordId, 'sub_domain' => $subDomain, 'record_type' => $recordType, 'value' => $value, 'ttl' => strval($ttl), 'record_line' => $line); return $this->makeRequest('Record.Modify', $data); }
    public function deleteRecord($domain, $recordId) { $data = array('record_id' => $recordId, 'domain' => $domain); return $this->makeRequest('Record.Delete', $data); }
    public function checkDomain($domain) { try { $this->makeRequest('Domain.Info', array('domain' => $domain)); return true; } catch (Exception $e) { return false; } }
    public function batchCreateCnameRecords($domain, $records) { $results = array('success' => 0, 'failed' => 0, 'errors' => array(), 'details' => array()); foreach ($records as $subDomain => $target) { try { $existingRecords = $this->listRecords($domain, $subDomain); $recordExists = false; $recordId = null; foreach ($existingRecords as $record) { if ($record['type'] == 'CNAME' && $record['name'] == $subDomain) { $recordExists = true; $recordId = $record['id']; break; } } if ($recordExists) { $this->modifyRecord($domain, $recordId, $subDomain, 'CNAME', $target); $results['details'][] = array('sub_domain' => $subDomain, 'action' => 'updated', 'status' => 'success', 'message' => "更新记录: {$subDomain}.{$domain} -> {$target}"); } else { $this->createRecord($domain, $subDomain, 'CNAME', $target); $results['details'][] = array('sub_domain' => $subDomain, 'action' => 'created', 'status' => 'success', 'message' => "创建记录: {$subDomain}.{$domain} -> {$target}"); } $results['success']++; usleep(200000); } catch (Exception $e) { $results['failed']++; $errorMsg = "操作记录 {$subDomain}.{$domain} -> {$target} 失败: " . $e->getMessage(); $results['errors'][] = $errorMsg; $results['details'][] = array('sub_domain' => $subDomain, 'action' => 'failed', 'status' => 'error', 'message' => $errorMsg); } } return $results; }
    public function fullSync($folders, $targetCname) { $allResults = array(); $summary = array('total_domains' => 0, 'success_domains' => 0, 'failed_domains' => 0, 'total_records' => 0, 'success_records' => 0, 'failed_records' => 0); foreach ($folders as $folder) { $domain = $folder['domain'] . '.' . $folder['tld']; $summary['total_domains']++; $summary['total_records']++; try { if (!$this->checkDomain($domain)) { $allResults[$domain] = array('status' => 'error', 'message' => "域名 {$domain} 不在您的DNSPod账户下", 'details' => array()); $summary['failed_domains']++; $summary['failed_records']++; continue; } $records = array($folder['prefix'] => $targetCname); $results = $this->batchCreateCnameRecords($domain, $records); $allResults[$domain] = array('status' => $results['failed'] == 0 ? 'success' : 'partial', 'message' => "成功: {$results['success']}, 失败: {$results['failed']}", 'details' => $results['details']); if ($results['failed'] == 0) { $summary['success_domains']++; $summary['success_records']++; } else { $summary['failed_domains']++; $summary['failed_records'] += $results['failed']; $summary['success_records'] += $results['success']; } } catch (Exception $e) { $allResults[$domain] = array('status' => 'error', 'message' => "同步失败: " . $e->getMessage(), 'details' => array()); $summary['failed_domains']++; $summary['failed_records']++; } } return array('results' => $allResults, 'summary' => $summary); }
}

class AutoDetector {
    // 支持三段式和四段式文件夹检测
    public static function scanThreePartFoldersLoose($baseDir = '.') { 
        $folders = array(); 
        $items = scandir($baseDir); 
        foreach ($items as $item) { 
            if ($item == '.' || $item == '..') continue; 
            $fullPath = $baseDir . '/' . $item; 
            if (is_dir($fullPath)) { 
                $parts = explode('-', $item); 
                if (count($parts) == 3) {
                    // 三段式
                    $prefix = $parts[0];
                    $domain = $parts[1];
                    $tld = $parts[2];
                    $fullDomain = "{$prefix}.{$domain}.{$tld}";
                    $folders[] = array('folder' => $item, 'prefix' => $prefix, 'domain' => $domain, 'tld' => $tld, 'full_domain' => $fullDomain);
                } elseif (count($parts) == 4 && $parts[0] == 'www') {
                    // 四段式 www-xxx-xxx-xxx
                    $prefix = 'www';
                    $domain = $parts[1] . '.' . $parts[2];
                    $tld = $parts[3];
                    $fullDomain = "{$prefix}.{$domain}.{$tld}";
                    $folders[] = array('folder' => $item, 'prefix' => $prefix, 'domain' => $domain, 'tld' => $tld, 'full_domain' => $fullDomain);
                }
            } 
        } 
        return $folders; 
    }
    public static function getCurrentDomain() { return isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : null; }
    public static function getCurrentDomainCnameRecord() { $currentDomain = self::getCurrentDomain(); if (!$currentDomain) return null; if (function_exists('dns_get_record')) { $dnsRecords = @dns_get_record($currentDomain, DNS_CNAME); if (!empty($dnsRecords)) return $dnsRecords[0]['target']; } return null; }
}

// ==================== 文件下载处理（通用） ====================
if (isset($_GET['download_zip']) && !empty($_GET['download_zip'])) {
    $file = basename($_GET['download_zip']); // 防止路径遍历
    $filePath = $currentDir . DIRECTORY_SEPARATOR . $file;
    if (file_exists($filePath) && is_file($filePath) && preg_match('/\.zip$/i', $file)) {
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($filePath));
        header('Cache-Control: no-cache');
        readfile($filePath);
        exit;
    } else {
        header('HTTP/1.0 404 Not Found');
        echo "文件不存在";
        exit;
    }
}

// ==================== 备份管理 AJAX 处理 ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    if (in_array($action, ['scan', 'pack', 'download', 'delete', 'clear_all', 'create_self_delete'])) {
        header('Content-Type: application/json');
        try {
            if ($action === 'scan') {
                $scan_result = scanDirectories($target_files);
                echo json_encode(['status' => 'success', 'folders' => $scan_result['folders'], 'target_files' => $scan_result['target_files'], 'ncoe_zips' => $scan_result['ncoe_zips'], 'message' => "扫描完成"]);
                exit;
            } elseif ($action === 'pack') {
                if (!class_exists('ZipArchive')) {
                    echo json_encode(['status' => 'error', 'message' => '服务器未启用 ZipArchive 扩展，无法打包']);
                    exit;
                }
                $scan_result = scanDirectories($target_files);
                $result = packFoldersAndFiles($scan_result['folders'], $scan_result['target_files'], $scan_result['ncoe_zips']);
                if ($result['success']) echo json_encode(['status' => 'success', 'message' => '打包成功', 'filename' => $result['filename']]);
                else echo json_encode(['status' => 'error', 'message' => '打包失败: ' . $result['error']]);
                exit;
            } elseif ($action === 'download') {
                $filename = isset($_POST['filename']) ? $_POST['filename'] : '';
                if (file_exists($filename)) { 
                    header('Content-Type: application/zip'); 
                    header('Content-Disposition: attachment; filename="' . basename($filename) . '"'); 
                    header('Content-Length: ' . filesize($filename)); 
                    readfile($filename); 
                    exit; 
                } else { 
                    http_response_code(404); 
                    echo "文件不存在"; 
                    exit; 
                }
            } elseif ($action === 'delete') {
                $filename = isset($_POST['filename']) ? $_POST['filename'] : '';
                if (file_exists($filename) && unlink($filename)) echo json_encode(['status' => 'success', 'message' => '打包文件删除成功']);
                else echo json_encode(['status' => 'error', 'message' => '打包文件删除失败']);
                exit;
            } elseif ($action === 'clear_all') {
                $scan_result = scanDirectories($target_files);
                $result = clearAll($scan_result['folders'], $scan_result['target_files'], $scan_result['ncoe_zips']);
                if ($result['success']) echo json_encode(['status' => 'success', 'message' => $result['message']]);
                else echo json_encode(['status' => 'error', 'message' => '清空失败: ' . $result['error']]);
                exit;
            } elseif ($action === 'create_self_delete') {
                $result = createSelfDeleteScript();
                echo json_encode($result);
                exit;
            }
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => '服务器错误: ' . $e->getMessage()]);
            exit;
        }
    }
}

// ==================== 页面变量初始化 ====================
$operationLog = array();      // 通用操作日志
$isExecuted = false;          // 是否执行过操作
$showFileList = true;         // 是否显示文件列表（首页）
$showFriendLinks = isset($_GET['friend_links']);
$showBatchReplace = isset($_GET['batch_replace']);
$showDnsManager = isset($_GET['dns_manager']);
$showBackup = isset($_GET['backup']);
$showNcoe = isset($_GET['ncoe']);

if ($showFriendLinks || $showDnsManager || $showBatchReplace || $showBackup || $showNcoe) {
    $showFileList = false;
}

// 1. 文件管理模块变量
$fileList = array();
$expandedDir = '';
$editingFile = '';
$creatingFile = '';
$fileContent = '';
$expandedFiles = array();

// 2. DNSPod 管理模块变量
$detectedFolders = array();
$syncResults = array();
$fullSyncResults = array();
$dnsMessage = '';
$dnsMessageType = '';

// 3. 站群配置模块变量
$operationLogNcoe = array();
$isExecutedNcoe = false;

// 4. 备份管理模块变量
$backupScanResult = null;
$backupSelfDeleteExists = file_exists('delete_self.php');

// ==================== 文件管理模块处理 ====================
// 文件操作处理（保存、删除、创建、批量替换等）
if (isset($_POST['save_file'])) {
    $isExecuted = true;
    $filePath = $_POST['file_path'];
    $content = $_POST['file_content'];
    if (isSafePath($filePath, $currentDir)) {
        if (file_put_contents($filePath, $content)) $operationLog[] = array('type' => 'success', 'msg' => '文件保存成功：' . getRelativePath($filePath, $currentDir));
        else $operationLog[] = array('type' => 'error', 'msg' => '文件保存失败');
    } else $operationLog[] = array('type' => 'error', 'msg' => '非法文件路径');
}
if (isset($_POST['delete_file'])) {
    $isExecuted = true;
    $filePath = $_POST['file_path'];
    if (isSafePath($filePath, $currentDir)) {
        if (unlink($filePath)) $operationLog[] = array('type' => 'success', 'msg' => '文件删除成功：' . getRelativePath($filePath, $currentDir));
        else $operationLog[] = array('type' => 'error', 'msg' => '文件删除失败');
    } else $operationLog[] = array('type' => 'error', 'msg' => '非法文件路径');
}
if (isset($_POST['create_file'])) {
    $isExecuted = true;
    $filePath = $_POST['new_file_path'];
    $content = $_POST['new_file_content'];
    if (isSafePath($filePath, $currentDir)) {
        if (strpos(basename($filePath), '.') === false) {
            if (!is_dir($filePath)) {
                if (mkdir($filePath, 0755, true)) $operationLog[] = array('type' => 'success', 'msg' => '文件夹创建成功：' . getRelativePath($filePath, $currentDir));
                else $operationLog[] = array('type' => 'error', 'msg' => '文件夹创建失败');
            } else $operationLog[] = array('type' => 'error', 'msg' => '文件夹已存在');
        } else {
            $dir = dirname($filePath);
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            if (file_put_contents($filePath, $content)) $operationLog[] = array('type' => 'success', 'msg' => '文件创建成功：' . getRelativePath($filePath, $currentDir));
            else $operationLog[] = array('type' => 'error', 'msg' => '文件创建失败');
        }
    } else $operationLog[] = array('type' => 'error', 'msg' => '非法文件路径');
}
// 批量替换
if (isset($_POST['batch_replace'])) {
    $isExecuted = true;
    $search = $_POST['search_text'];
    $replace = $_POST['replace_text'];
    if (empty($search)) $operationLog[] = array('type' => 'error', 'msg' => '查找文本不能为空');
    else {
        $folders = array();
        $items = scandir($currentDir);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            $path = $currentDir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
        }
        $totalFiles = 0; $replacedFiles = 0;
        foreach ($folders as $folder) {
            $htmlFiles = array();
            $items = scandir($folder);
            foreach ($items as $item) {
                if ($item == '.' || $item == '..') continue;
                $path = $folder . DIRECTORY_SEPARATOR . $item;
                if (is_file($path) && preg_match('/\.html?$/i', $item)) $htmlFiles[] = $path;
            }
            foreach ($htmlFiles as $file) {
                $totalFiles++;
                $content = file_get_contents($file);
                $newContent = str_replace($search, $replace, $content, $count);
                if ($count > 0 && file_put_contents($file, $newContent)) { $replacedFiles++; $operationLog[] = array('type' => 'success', 'msg' => "文件替换成功：".getRelativePath($file,$currentDir)." (替换 $count 处)"); }
            }
        }
        $operationLog[] = array('type' => 'info', 'msg' => "批量替换完成：共扫描 $totalFiles 个HTML文件，成功替换 $replacedFiles 个文件");
    }
}
// 替换 HTTPS
if (isset($_POST['replace_https'])) {
    $isExecuted = true;
    $folders = array();
    $items = scandir($currentDir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $currentDir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
    }
    $totalFiles = 0; $replacedFiles = 0; $totalReplacements = 0;
    foreach ($folders as $folder) {
        $htmlFiles = array();
        $items = scandir($folder);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            $path = $folder . DIRECTORY_SEPARATOR . $item;
            if (is_file($path) && preg_match('/\.html?$/i', $item)) $htmlFiles[] = $path;
        }
        foreach ($htmlFiles as $file) {
            $totalFiles++;
            $content = file_get_contents($file);
            $count1 = 0; $count2 = 0;
            $newContent = str_replace('http://img', '//img', $content, $count1);
            $newContent = str_replace('https://img', '//img', $newContent, $count2);
            $count = $count1 + $count2;
            if ($count > 0 && file_put_contents($file, $newContent)) { $replacedFiles++; $totalReplacements += $count; $operationLog[] = array('type' => 'success', 'msg' => "HTTPS替换成功：".getRelativePath($file,$currentDir)." (替换 $count 处)"); }
        }
    }
    $operationLog[] = array('type' => 'info', 'msg' => "HTTPS替换完成：共扫描 $totalFiles 个HTML文件，成功替换 $replacedFiles 个文件，共 $totalReplacements 处替换");
}
// 植入 ICO
if (isset($_POST['download_ico'])) {
    $isExecuted = true;
    $folders = array();
    $items = scandir($currentDir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $currentDir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
    }
    $icoUrl = 'https://seo.ncoe.cn/favicon.ico';
    $icoContent = @file_get_contents($icoUrl);
    if ($icoContent === false) $operationLog[] = array('type' => 'error', 'msg' => '无法下载ICO文件');
    else {
        $downloadedFolders = 0;
        foreach ($folders as $folder) {
            $icoPath = $folder . DIRECTORY_SEPARATOR . 'favicon.ico';
            if (file_put_contents($icoPath, $icoContent)) { $downloadedFolders++; $operationLog[] = array('type' => 'success', 'msg' => "ICO图标植入成功：".getRelativePath($icoPath,$currentDir)); }
            else $operationLog[] = array('type' => 'error', 'msg' => "ICO图标植入失败：".getRelativePath($icoPath,$currentDir));
        }
        $operationLog[] = array('type' => 'info', 'msg' => "ICO图标植入完成：共处理 ".count($folders)." 个文件夹，成功植入 $downloadedFolders 个文件夹");
    }
}
// 友情链接批量替换
if (isset($_POST['friend_links_replace'])) {
    $isExecuted = true;
    $newContent = $_POST['friend_links_content'];
    $replaceType = $_POST['replace_type'];
    if (empty($newContent)) $operationLog[] = array('type' => 'error', 'msg' => '友情链接内容不能为空');
    else {
        $folders = array();
        $items = scandir($currentDir);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            $path = $currentDir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
        }
        $totalFiles = 0; $replacedFiles = 0;
        foreach ($folders as $folder) {
            $htmlFiles = array();
            $items = scandir($folder);
            foreach ($items as $item) {
                if ($item == '.' || $item == '..') continue;
                $path = $folder . DIRECTORY_SEPARATOR . $item;
                if (is_file($path) && preg_match('/\.html?$/i', $item)) $htmlFiles[] = $path;
            }
            foreach ($htmlFiles as $file) {
                $totalFiles++;
                $content = file_get_contents($file);
                $startMarker = '<!-- 友情链接矩阵开始 -->';
                $endMarker = '<!-- 友情链接矩阵结束 -->';
                $startPos = strpos($content, $startMarker);
                $endPos = strpos($content, $endMarker);
                if ($startPos !== false && $endPos !== false) {
                    $endPos += strlen($endMarker);
                    if ($replaceType == 'replace_all') $newFileContent = substr($content, 0, $startPos) . $startMarker . "\n" . $newContent . "\n" . $endMarker . substr($content, $endPos);
                    elseif ($replaceType == 'add_to_begin') $newFileContent = substr($content, 0, $startPos + strlen($startMarker)) . "\n" . $newContent . substr($content, $startPos + strlen($startMarker));
                    elseif ($replaceType == 'add_to_end') $newFileContent = substr($content, 0, $endPos - strlen($endMarker)) . $newContent . "\n" . substr($content, $endPos - strlen($endMarker));
                    if (file_put_contents($file, $newFileContent)) { $replacedFiles++; $operationLog[] = array('type' => 'success', 'msg' => "友情链接替换成功：".getRelativePath($file,$currentDir)); }
                    else $operationLog[] = array('type' => 'error', 'msg' => "友情链接替换失败：".getRelativePath($file,$currentDir));
                } else $operationLog[] = array('type' => 'warning', 'msg' => "未找到友情链接标记：".getRelativePath($file,$currentDir));
            }
        }
        $operationLog[] = array('type' => 'info', 'msg' => "友情链接替换完成：共扫描 $totalFiles 个HTML文件，成功替换 $replacedFiles 个文件");
    }
}
// 友情链接查找
if (isset($_POST['friend_links_search'])) {
    $isExecuted = true;
    $searchCode = $_POST['search_code'];
    if (empty($searchCode)) $operationLog[] = array('type' => 'error', 'msg' => '查找代码不能为空');
    else {
        $folders = array();
        $items = scandir($currentDir);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            $path = $currentDir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
        }
        $foundFiles = 0; $foundLinks = array();
        foreach ($folders as $folder) {
            $indexFile = $folder . DIRECTORY_SEPARATOR . 'index.html';
            if (is_file($indexFile)) {
                $content = file_get_contents($indexFile);
                if (strpos($content, $searchCode) !== false) {
                    $foundFiles++;
                    $foundLinks[] = array('file' => getRelativePath($indexFile, $currentDir), 'domain' => getFileDomainUrl($indexFile, $currentDir));
                    $operationLog[] = array('type' => 'success', 'msg' => "找到匹配文件：".getRelativePath($indexFile,$currentDir));
                }
            }
        }
        if ($foundFiles > 0) { $operationLog[] = array('type' => 'info', 'msg' => "查找完成：共找到 $foundFiles 个包含指定代码的文件"); $_SESSION['found_links'] = $foundLinks; $_SESSION['search_code'] = $searchCode; }
        else $operationLog[] = array('type' => 'warning', 'msg' => '未找到任何包含指定代码的文件');
    }
}
// 友情链接批量删除
if (isset($_POST['friend_links_batch_delete'])) {
    $isExecuted = true;
    $deleteCode = $_POST['delete_code'];
    $deleteMode = $_POST['delete_mode'];
    if (empty($deleteCode)) $operationLog[] = array('type' => 'error', 'msg' => '删除代码不能为空');
    else {
        $folders = array();
        $items = scandir($currentDir);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            $path = $currentDir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
        }
        $totalFiles = 0; $deletedFiles = 0;
        foreach ($folders as $folder) {
            $indexFile = $folder . DIRECTORY_SEPARATOR . 'index.html';
            if (is_file($indexFile)) {
                $totalFiles++;
                $content = file_get_contents($indexFile);
                if (strpos($content, $deleteCode) !== false) {
                    if ($deleteMode == 'link_only') $newContent = str_replace($deleteCode, '', $content);
                    else {
                        $linkPos = strpos($content, $deleteCode);
                        $divStartPos = false;
                        $searchPos = $linkPos;
                        while ($searchPos > 0) {
                            $searchPos = strrpos(substr($content, 0, $searchPos), '<div');
                            if ($searchPos !== false) {
                                $divEndPos = strpos($content, '>', $searchPos);
                                if ($divEndPos !== false && $divEndPos < $linkPos) { $divStartPos = $searchPos; break; }
                                $searchPos--;
                            } else break;
                        }
                        $divEndPos = false;
                        if ($divStartPos !== false) {
                            $tempPos = $divStartPos; $divDepth = 0; $inDiv = false;
                            while ($tempPos < strlen($content)) {
                                if (substr($content, $tempPos, 4) == '<div') { $divDepth++; $inDiv = true; }
                                elseif (substr($content, $tempPos, 6) == '</div') { $divDepth--; if ($divDepth == 0 && $inDiv) { $divEndPos = $tempPos + 6; break; } }
                                $tempPos++;
                            }
                        }
                        if ($divStartPos !== false && $divEndPos !== false) {
                            $divStartTagEnd = strpos($content, '>', $divStartPos) + 1;
                            $newContent = substr($content, 0, $divStartTagEnd) . "\n<!-- 友情链接矩阵开始 -->\n<!-- 友情链接矩阵结束 -->\n" . substr($content, $divEndPos - 6);
                        } else { $newContent = $content; $operationLog[] = array('type' => 'warning', 'msg' => "未找到完整的div标签，仅删除链接：".getRelativePath($indexFile,$currentDir)); }
                    }
                    if (file_put_contents($indexFile, $newContent)) { $deletedFiles++; $operationLog[] = array('type' => 'success', 'msg' => "链接删除成功：".getRelativePath($indexFile,$currentDir)); }
                    else $operationLog[] = array('type' => 'error', 'msg' => "链接删除失败：".getRelativePath($indexFile,$currentDir));
                } else $operationLog[] = array('type' => 'warning', 'msg' => "未找到指定的链接代码：".getRelativePath($indexFile,$currentDir));
            }
        }
        $operationLog[] = array('type' => 'info', 'msg' => "链接批量删除完成：共扫描 $totalFiles 个index.html文件，成功删除 $deletedFiles 个文件中的链接");
    }
}
// 友情链接矩阵检测
if (isset($_POST['detect_friend_links'])) {
    $isExecuted = true;
    $folders = array();
    $items = scandir($currentDir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $currentDir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
    }
    $totalFiles = 0; $hasMatrixFiles = 0; $noMatrixFiles = 0; $matrixFiles = array(); $noMatrixFilesList = array();
    foreach ($folders as $folder) {
        $indexFile = $folder . DIRECTORY_SEPARATOR . 'index.html';
        if (is_file($indexFile)) {
            $totalFiles++;
            $content = file_get_contents($indexFile);
            if (strpos($content, '<!-- 友情链接矩阵开始 -->') !== false && strpos($content, '<!-- 友情链接矩阵结束 -->') !== false) {
                $hasMatrixFiles++;
                $matrixFiles[] = array('file' => getRelativePath($indexFile, $currentDir), 'domain' => getFileDomainUrl($indexFile, $currentDir));
                $operationLog[] = array('type' => 'success', 'msg' => "检测到友情链接矩阵：".getRelativePath($indexFile,$currentDir));
            } else {
                $noMatrixFiles++;
                $noMatrixFilesList[] = array('file' => getRelativePath($indexFile, $currentDir), 'domain' => getFileDomainUrl($indexFile, $currentDir));
                $operationLog[] = array('type' => 'warning', 'msg' => "未检测到友情链接矩阵：".getRelativePath($indexFile,$currentDir));
            }
        }
    }
    $operationLog[] = array('type' => 'info', 'msg' => "友情链接矩阵检测完成：共扫描 $totalFiles 个文件，其中 $hasMatrixFiles 个有矩阵，$noMatrixFiles 个无矩阵");
    $_SESSION['matrix_files'] = $matrixFiles;
    $_SESSION['no_matrix_files'] = $noMatrixFilesList;
}
// 友情链接智能替换
if (isset($_POST['friend_links_smart_replace'])) {
    $isExecuted = true;
    $linkCode = $_POST['link_code'];
    if (empty($linkCode)) $operationLog[] = array('type' => 'error', 'msg' => '链接代码不能为空');
    else {
        $folders = array();
        $items = scandir($currentDir);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            $path = $currentDir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
        }
        $totalFiles = 0; $replacedFiles = 0;
        foreach ($folders as $folder) {
            $indexFile = $folder . DIRECTORY_SEPARATOR . 'index.html';
            if (is_file($indexFile)) {
                $totalFiles++;
                $content = file_get_contents($indexFile);
                $linkPos = strpos($content, $linkCode);
                if ($linkPos !== false) {
                    $divStartPos = false;
                    $searchPos = $linkPos;
                    while ($searchPos > 0) {
                        $searchPos = strrpos(substr($content, 0, $searchPos), '<div');
                        if ($searchPos !== false) {
                            $divEndPos = strpos($content, '>', $searchPos);
                            if ($divEndPos !== false && $divEndPos < $linkPos) { $divStartPos = $searchPos; break; }
                            $searchPos--;
                        } else break;
                    }
                    $divEndPos = false;
                    if ($divStartPos !== false) {
                        $tempPos = $divStartPos; $divDepth = 0; $inDiv = false;
                        while ($tempPos < strlen($content)) {
                            if (substr($content, $tempPos, 4) == '<div') { $divDepth++; $inDiv = true; }
                            elseif (substr($content, $tempPos, 6) == '</div') { $divDepth--; if ($divDepth == 0 && $inDiv) { $divEndPos = $tempPos + 6; break; } }
                            $tempPos++;
                        }
                    }
                    if ($divStartPos !== false && $divEndPos !== false) {
                        $divStartTagEnd = strpos($content, '>', $divStartPos) + 1;
                        $newContent = substr($content, 0, $divStartTagEnd) . "\n<!-- 友情链接矩阵开始 -->\n<!-- 友情链接矩阵结束 -->\n" . substr($content, $divEndPos - 6);
                        if (file_put_contents($indexFile, $newContent)) { $replacedFiles++; $operationLog[] = array('type' => 'success', 'msg' => "友情链接智能替换成功：".getRelativePath($indexFile,$currentDir)); }
                        else $operationLog[] = array('type' => 'error', 'msg' => "友情链接智能替换失败：".getRelativePath($indexFile,$currentDir));
                    } else $operationLog[] = array('type' => 'warning', 'msg' => "未找到包含指定链接的完整div标签：".getRelativePath($indexFile,$currentDir));
                } else $operationLog[] = array('type' => 'warning', 'msg' => "未找到指定的链接代码：".getRelativePath($indexFile,$currentDir));
            }
        }
        $operationLog[] = array('type' => 'info', 'msg' => "友情链接智能替换完成：共扫描 $totalFiles 个index.html文件，成功替换 $replacedFiles 个文件");
    }
}
// 友情链接打乱
if (isset($_POST['shuffle_friend_links'])) {
    $isExecuted = true;
    $folders = array();
    $items = scandir($currentDir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $currentDir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) $folders[] = $path;
    }
    $totalFiles = 0; $shuffledFiles = 0;
    foreach ($folders as $folder) {
        $indexFile = $folder . DIRECTORY_SEPARATOR . 'index.html';
        if (is_file($indexFile)) {
            $totalFiles++;
            $content = file_get_contents($indexFile);
            $startMarker = '<!-- 友情链接矩阵开始 -->';
            $endMarker = '<!-- 友情链接矩阵结束 -->';
            $startPos = strpos($content, $startMarker);
            $endPos = strpos($content, $endMarker);
            if ($startPos !== false && $endPos !== false) {
                $contentStart = $startPos + strlen($startMarker);
                $contentEnd = $endPos;
                $linksContent = substr($content, $contentStart, $contentEnd - $contentStart);
                preg_match_all('/<a\s+[^>]*href=["\'][^"\']*["\'][^>]*>.*?<\/a>/i', $linksContent, $matches);
                $links = $matches[0];
                if (count($links) > 1) {
                    shuffle($links);
                    $newLinksContent = implode("\n", $links);
                    $newContent = substr($content, 0, $contentStart) . "\n" . $newLinksContent . "\n" . substr($content, $contentEnd);
                    if (file_put_contents($indexFile, $newContent)) { $shuffledFiles++; $operationLog[] = array('type' => 'success', 'msg' => "友情链接打乱成功：".getRelativePath($indexFile,$currentDir)." (打乱 ".count($links)." 个链接)"); }
                    else $operationLog[] = array('type' => 'error', 'msg' => "友情链接打乱失败：".getRelativePath($indexFile,$currentDir));
                } else $operationLog[] = array('type' => 'warning', 'msg' => "友情链接数量不足，无需打乱：".getRelativePath($indexFile,$currentDir));
            } else $operationLog[] = array('type' => 'warning', 'msg' => "未找到友情链接矩阵：".getRelativePath($indexFile,$currentDir));
        }
    }
    $operationLog[] = array('type' => 'info', 'msg' => "友情链接打乱完成：共扫描 $totalFiles 个文件，成功打乱 $shuffledFiles 个文件的友情链接");
}

// 获取文件列表函数
function getAllowedFileList($dir) {
    global $folderPattern, $folderPattern4;
    $allowedFiles = array('.htaccess', 'ncoe.php', 'ftp.php');
    $files = array();
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path) && (preg_match($folderPattern, $item) || preg_match($folderPattern4, $item))) {
            $files[] = array('name' => $item, 'path' => $path, 'is_dir' => true, 'size' => '', 'modified' => date('Y-m-d H:i:s', filemtime($path)));
        } elseif (is_file($path) && in_array($item, $allowedFiles)) {
            $files[] = array('name' => $item, 'path' => $path, 'is_dir' => false, 'size' => formatFileSize(filesize($path)), 'modified' => date('Y-m-d H:i:s', filemtime($path)));
        }
    }
    usort($files, function($a, $b) { if ($a['is_dir'] && !$b['is_dir']) return -1; if (!$a['is_dir'] && $b['is_dir']) return 1; return strcmp($a['name'], $b['name']); });
    return $files;
}
function getDirectoryFiles($dir) {
    $files = array();
    if (!is_dir($dir)) return $files;
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_file($path)) {
            $files[] = array('name' => $item, 'path' => $path, 'is_dir' => false, 'size' => formatFileSize(filesize($path)), 'modified' => date('Y-m-d H:i:s', filemtime($path)));
        }
    }
    usort($files, function($a, $b) { return strcmp($a['name'], $b['name']); });
    return $files;
}
if (isset($_GET['edit'])) {
    $editFile = $_GET['edit'];
    if (isSafePath($editFile, $currentDir) && is_file($editFile)) {
        $fileContent = htmlspecialchars(file_get_contents($editFile), ENT_QUOTES, 'UTF-8');
        $editingFile = $editFile;
    }
}
if (isset($_GET['expand'])) {
    $expandDir = $_GET['expand'];
    if (isSafePath($expandDir, $currentDir) && is_dir($expandDir)) {
        $expandedDir = $expandDir;
    }
}
if (isset($_GET['create'])) {
    $createPath = $_GET['create'];
    if (isSafePath($createPath, $currentDir)) {
        $creatingFile = $createPath;
    }
}
$fileList = getAllowedFileList($currentDir);
if ($expandedDir) $expandedFiles = getDirectoryFiles($expandedDir);

// ==================== DNSPod 管理模块处理 ====================
if ($showDnsManager) {
    try {
        $dnspod = new DnspodManager(DNSPOD_ID, DNSPOD_TOKEN);
        $detectedFolders = AutoDetector::scanThreePartFoldersLoose();
        if (empty($detectedFolders)) $detectedFolders = AutoDetector::scanThreePartFoldersLoose();
        if ($_POST) {
            $action = $_POST['action'] ?? '';
            switch ($action) {
                case 'full_sync':
                    if (empty($detectedFolders)) throw new Exception('没有检测到三段式文件夹');
                    $targetCname = $_POST['target_cname'] ?? null;
                    if (empty($targetCname)) throw new Exception('请指定目标CNAME地址');
                    $fullSyncResults = $dnspod->fullSync($detectedFolders, $targetCname);
                    $summary = $fullSyncResults['summary'];
                    $dnsMessage = "一键同步解析完成！总计: {$summary['total_domains']} 个域名, 成功: {$summary['success_domains']} 个域名, 失败: {$summary['failed_domains']} 个域名";
                    $dnsMessageType = 'success';
                    break;
                case 'sync_single':
                    $domain = $_POST['domain'] ?? '';
                    $subDomain = $_POST['sub_domain'] ?? '';
                    $targetCname = $_POST['target_cname'] ?? '';
                    if (empty($domain) || empty($subDomain) || empty($targetCname)) throw new Exception('域名、子域名和目标CNAME都不能为空');
                    if (!$dnspod->checkDomain($domain)) throw new Exception("域名 {$domain} 不在您的DNSPod账户下");
                    $records = array($subDomain => $targetCname);
                    $results = $dnspod->batchCreateCnameRecords($domain, $records);
                    $syncResults[$domain] = array('status' => $results['failed'] == 0 ? 'success' : 'partial', 'message' => "成功: {$results['success']}, 失败: {$results['failed']}", 'details' => $results['details']);
                    $dnsMessage = "域名 {$domain} 解析同步完成！";
                    $dnsMessageType = 'success';
                    break;
            }
        }
    } catch (Exception $e) {
        $dnsMessage = 'DNSPod错误: ' . $e->getMessage();
        $dnsMessageType = 'error';
    }
    $currentDomain = AutoDetector::getCurrentDomain();
    $currentCname = AutoDetector::getCurrentDomainCnameRecord();
}

// ==================== 站群配置模块处理 ====================
if ($showNcoe) {
    $htaccessPath = '.htaccess';
    $rewriteEngineMark = 'RewriteEngine On';
    $htmlExt = array('html', 'htm');
    $matchedFolders = array();
    $renameLog = array();

    // 文件上传处理
    if (isset($_FILES['zipfile']) && $_FILES['zipfile']['error'] === UPLOAD_ERR_OK) {
        $isExecutedNcoe = true;
        $uploadedFile = $_FILES['zipfile'];
        $fileName = $uploadedFile['name'];
        $fileTmpPath = $uploadedFile['tmp_name'];
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if ($fileType !== 'zip') {
            $operationLogNcoe[] = array('type' => 'error', 'msg' => '只支持ZIP格式的压缩包文件！');
        } else {
            $tempDir = $currentDir . DIRECTORY_SEPARATOR . 'temp_unzip_' . time();
            if (!mkdir($tempDir, 0755)) {
                $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法创建临时解压目录，请检查目录权限！');
            } else {
                $zip = new ZipArchive();
                if ($zip->open($fileTmpPath) === TRUE) {
                    $zip->extractTo($tempDir);
                    $zip->close();
                    $operationLogNcoe[] = array('type' => 'success', 'msg' => '成功解压压缩包：' . $fileName);
                    $moveCount = 0;
                    $dirIterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tempDir, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
                    foreach ($dirIterator as $item) {
                        $targetPath = $currentDir . DIRECTORY_SEPARATOR . substr($item->getPathname(), strlen($tempDir) + 1);
                        if ($item->isDir()) { if (!is_dir($targetPath)) mkdir($targetPath, 0755, true); }
                        else { if (!file_exists($targetPath)) { rename($item->getPathname(), $targetPath); $moveCount++; } else { $operationLogNcoe[] = array('type' => 'warning', 'msg' => '文件已存在，跳过：' . basename($targetPath)); } }
                    }
                    function removeTempDir($dir) { if (!is_dir($dir)) return; $items = scandir($dir); foreach ($items as $item) { if ($item == '.' || $item == '..') continue; $path = $dir . DIRECTORY_SEPARATOR . $item; if (is_dir($path)) removeTempDir($path); else unlink($path); } rmdir($dir); }
                    removeTempDir($tempDir);
                    $operationLogNcoe[] = array('type' => 'success', 'msg' => '解压完成！共解压 ' . $moveCount . ' 个文件到当前目录');
                    $operationLogNcoe[] = array('type' => 'notice', 'msg' => '请点击"开始执行站群配置"按钮继续处理解压后的文件');
                } else {
                    $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法解压ZIP文件，文件可能已损坏！');
                    if (is_dir($tempDir)) rmdir($tempDir);
                }
            }
        }
    }

    // 生成SEO页面
    if (isset($_POST['generate_seo'])) {
        $isExecutedNcoe = true;
        $matchedFolders = array();
        $dirHandle = opendir($currentDir);
        if (!$dirHandle) { $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法访问当前目录'); }
        else {
            while (($file = readdir($dirHandle)) !== false) {
                if ($file == '.' || $file == '..' || !is_dir($file)) continue;
                if (preg_match($folderPattern, $file, $matches)) {
                    $subdomain = $matches[1] . '.' . $matches[2] . '.' . $matches[3];
                    $matchedFolders[$file] = $subdomain;
                } elseif (preg_match($folderPattern4, $file, $matches)) {
                    $subdomain = 'www.' . $matches[2] . '.' . $matches[3] . '.' . $matches[4];
                    $matchedFolders[$file] = $subdomain;
                }
            }
            closedir($dirHandle);
        }
        if (empty($matchedFolders)) { $operationLogNcoe[] = array('type' => 'error', 'msg' => '未找到符合格式的文件夹，无法生成SEO页面！'); }
        else {
            $operationLogNcoe[] = array('type' => 'success', 'msg' => '共检测到 ' . count($matchedFolders) . ' 个目标文件夹：');
            foreach ($matchedFolders as $folder => $domain) { $operationLogNcoe[] = array('type' => 'list', 'msg' => '文件夹：' . $folder . ' → 子域名：' . $domain); }
            $operationLogNcoe[] = array('type' => 'title', 'msg' => '开始生成SEO页面');
            $seoMapping = readSeoMapping();
            $operationLogNcoe[] = array('type' => 'info', 'msg' => '读取到 ' . count($seoMapping) . ' 个现有的关键词映射');
            $seoContent = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>站点导航 - 成都舜王科技有限公司</title><style>body{font-family:"Microsoft YaHei",Arial,sans-serif;margin:0;padding:20px;background:#f5f7fa;}.container{max-width:1200px;margin:0 auto;background:white;padding:30px;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}h1{text-align:center;color:#2c5282;margin-bottom:30px;}.link-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;}.link-grid a{display:block;padding:15px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;text-align:center;text-decoration:none;color:#2c5282;font-size:16px;}.link-grid a:hover{background:#3182ce;color:white;border-color:#3182ce;}.footer{text-align:center;margin-top:30px;color:#718096;font-size:14px;}@media (max-width:768px){.link-grid{grid-template-columns:repeat(2,1fr);}}@media (max-width:480px){.link-grid{grid-template-columns:1fr;}}</style></head><body><div class="container"><h1>站点导航</h1><div class="link-grid">';
            $successCount = 0; $failCount = 0; $reusedCount = 0; $newMapping = array();
            uksort($matchedFolders, function($a, $b) { preg_match('/^([a-zA-Z]*)(\d+)/', $a, $ma); preg_match('/^([a-zA-Z]*)(\d+)/', $b, $mb); $na = isset($ma[2])?intval($ma[2]):0; $nb = isset($mb[2])?intval($mb[2]):0; return $na - $nb; });
            foreach ($matchedFolders as $folder => $subdomain) {
                $indexFile = $currentDir . DIRECTORY_SEPARATOR . $folder . DIRECTORY_SEPARATOR . 'index.html';
                if (isset($seoMapping[$subdomain])) {
                    $keyword = $seoMapping[$subdomain];
                    $seoContent .= '<a href="http://' . $subdomain . '/" target="_blank">' . htmlspecialchars($keyword) . '</a>';
                    $operationLogNcoe[] = array('type' => 'info', 'msg' => '【' . $subdomain . '】：复用现有关键词 "' . $keyword . '"');
                    $newMapping[$subdomain] = $keyword; $reusedCount++; continue;
                }
                if (file_exists($indexFile)) {
                    $content = file_get_contents($indexFile);
                    $keywords = array();
                    if (preg_match('/<meta\s+name="keywords"\s+content="([^"]*)"/i', $content, $matches)) {
                        $keywordString = $matches[1];
                        $keywords = array_map('trim', explode(',', $keywordString));
                        $keywords = array_filter($keywords);
                    }
                    if (!empty($keywords)) {
                        if (count($keywords) > 1) { $availableKeywords = $keywords; array_shift($availableKeywords); $randomKey = array_rand($availableKeywords); $keyword = $availableKeywords[$randomKey]; }
                        else $keyword = $keywords[0];
                        $seoContent .= '<a href="http://' . $subdomain . '/" target="_blank">' . htmlspecialchars($keyword) . '</a>';
                        $operationLogNcoe[] = array('type' => 'success', 'msg' => '【' . $subdomain . '】：使用新关键词 "' . $keyword . '"');
                        $newMapping[$subdomain] = $keyword; $successCount++;
                    } else {
                        $keyword = $folder;
                        $seoContent .= '<a href="http://' . $subdomain . '/" target="_blank">' . htmlspecialchars($keyword) . '</a>';
                        $operationLogNcoe[] = array('type' => 'warning', 'msg' => '【' . $subdomain . '】：未找到keywords，使用文件夹名');
                        $newMapping[$subdomain] = $keyword; $failCount++;
                    }
                } else {
                    $keyword = $subdomain;
                    $seoContent .= '<a href="http://' . $subdomain . '/" target="_blank">' . htmlspecialchars($keyword) . '</a>';
                    $operationLogNcoe[] = array('type' => 'error', 'msg' => '【' . $subdomain . '】：index.html文件不存在，使用域名作为链接文本');
                    $newMapping[$subdomain] = $keyword; $failCount++;
                }
            }
            $seoContent .= '</div><div class="footer">版权所有 © 成都舜王科技有限公司 - 自动生成于 ' . date('Y-m-d H:i:s') . '</div></div></body></html>';
            if (saveSeoMapping($newMapping)) $operationLogNcoe[] = array('type' => 'success', 'msg' => '成功保存SEO关键词映射');
            else $operationLogNcoe[] = array('type' => 'warning', 'msg' => '无法保存SEO关键词映射，但页面已生成');
            if (file_put_contents('seo.html', $seoContent)) {
                $operationLogNcoe[] = array('type' => 'success', 'msg' => '成功生成SEO链接页面：seo.html');
                $operationLogNcoe[] = array('type' => 'info', 'msg' => '关键词统计：复用 ' . $reusedCount . ' 个，新增 ' . $successCount . ' 个，备选 ' . $failCount . ' 个');
                $operationLogNcoe[] = array('type' => 'notice', 'msg' => '访问地址：<a href="seo.html" target="_blank">点击打开SEO导航页面</a>');
            } else $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法生成SEO链接页面');
        }
    }

    // 执行站群配置
    if (isset($_POST['execute'])) {
        $isExecutedNcoe = true;
        $operationLogNcoe[] = array('type' => 'title', 'msg' => '开始处理主目录下的HTML文件');
        $mainDirHtmlProcessed = array();
        $dirHandle = opendir($currentDir);
        if (!$dirHandle) $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法访问当前目录');
        else {
            while (($file = readdir($dirHandle)) !== false) {
                if ($file == '.' || $file == '..' || is_dir($file)) continue;
                $fileExt = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if (in_array($fileExt, $htmlExt)) {
                    $fileName = pathinfo($file, PATHINFO_FILENAME);
                    if (preg_match($folderPattern, $fileName, $matches) || preg_match($folderPattern4, $fileName, $matches)) {
                        $folderName = $fileName;
                        if (!is_dir($folderName)) {
                            if (mkdir($folderName, 0755)) {
                                $operationLogNcoe[] = array('type' => 'success', 'msg' => '自动创建目录：' . $folderName);
                                $oldPath = $currentDir . DIRECTORY_SEPARATOR . $file;
                                $newPath = $currentDir . DIRECTORY_SEPARATOR . $folderName . DIRECTORY_SEPARATOR . 'index.html';
                                if (rename($oldPath, $newPath)) { $operationLogNcoe[] = array('type' => 'success', 'msg' => '移动 ' . $file . ' → /' . $folderName . '/index.html'); $mainDirHtmlProcessed[] = $file; }
                                else $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法移动文件 ' . $file);
                            } else $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法创建目录：' . $folderName);
                        } else {
                            $newPath = $currentDir . DIRECTORY_SEPARATOR . $folderName . DIRECTORY_SEPARATOR . 'index.html';
                            if (!file_exists($newPath)) {
                                $oldPath = $currentDir . DIRECTORY_SEPARATOR . $file;
                                if (rename($oldPath, $newPath)) { $operationLogNcoe[] = array('type' => 'success', 'msg' => '移动 ' . $file . ' → /' . $folderName . '/index.html'); $mainDirHtmlProcessed[] = $file; }
                                else $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法移动文件 ' . $file);
                            } else $operationLogNcoe[] = array('type' => 'warning', 'msg' => '跳过 ' . $file . '：目标文件夹中已存在index.html');
                        }
                    }
                }
            }
            closedir($dirHandle);
            if (!empty($mainDirHtmlProcessed)) $operationLogNcoe[] = array('type' => 'success', 'msg' => '主目录HTML文件处理完成：共处理 ' . count($mainDirHtmlProcessed) . ' 个文件');
            else $operationLogNcoe[] = array('type' => 'info', 'msg' => '主目录下未找到符合格式的HTML文件需要处理');
        }
        $operationLogNcoe[] = array('type' => 'title', 'msg' => '开始扫描目标文件夹');
        $matchedFolders = array();
        $dirHandle = opendir($currentDir);
        if (!$dirHandle) $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法访问当前目录');
        else {
            while (($file = readdir($dirHandle)) !== false) {
                if ($file == '.' || $file == '..' || !is_dir($file)) continue;
                if (preg_match($folderPattern, $file, $matches)) {
                    $subdomain = $matches[1] . '.' . $matches[2] . '.' . $matches[3];
                    $matchedFolders[$file] = $subdomain;
                } elseif (preg_match($folderPattern4, $file, $matches)) {
                    $subdomain = 'www.' . $matches[2] . '.' . $matches[3] . '.' . $matches[4];
                    $matchedFolders[$file] = $subdomain;
                }
            }
            closedir($dirHandle);
        }
        if (empty($matchedFolders)) { $operationLogNcoe[] = array('type' => 'info', 'msg' => '未找到符合格式的文件夹，无需操作！'); }
        else {
            $operationLogNcoe[] = array('type' => 'success', 'msg' => '共检测到 ' . count($matchedFolders) . ' 个目标文件夹：');
            foreach ($matchedFolders as $folder => $domain) { $operationLogNcoe[] = array('type' => 'list', 'msg' => '文件夹：' . $folder . ' → 子域名：' . $domain); }
            $operationLogNcoe[] = array('type' => 'title', 'msg' => '开始扫描子目录中的HTML文件');
            $autoCreatedFolders = array();
            $dirHandle = opendir($currentDir);
            if (!$dirHandle) $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法访问当前目录');
            else {
                while (($file = readdir($dirHandle)) !== false) {
                    if ($file == '.' || $file == '..' || is_dir($file)) continue;
                    $fileExt = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if (in_array($fileExt, $htmlExt)) {
                        $fileName = pathinfo($file, PATHINFO_FILENAME);
                        if (preg_match($folderPattern, $fileName, $matches) || preg_match($folderPattern4, $fileName, $matches)) {
                            $folderName = $fileName;
                            if (!is_dir($folderName)) {
                                if (mkdir($folderName, 0755)) {
                                    $operationLogNcoe[] = array('type' => 'success', 'msg' => '自动创建目录：' . $folderName);
                                    $autoCreatedFolders[] = $folderName;
                                    $oldPath = $currentDir . DIRECTORY_SEPARATOR . $file;
                                    $newPath = $currentDir . DIRECTORY_SEPARATOR . $folderName . DIRECTORY_SEPARATOR . 'index.html';
                                    if (file_exists($newPath)) $operationLogNcoe[] = array('type' => 'warning', 'msg' => '【' . $folderName . '】：index.html 已存在，跳过文件 ' . $file);
                                    else {
                                        if (rename($oldPath, $newPath)) $operationLogNcoe[] = array('type' => 'success', 'msg' => '【' . $folderName . '】：移动 ' . $file . ' → index.html');
                                        else $operationLogNcoe[] = array('type' => 'error', 'msg' => '【' . $folderName . '】：无法移动文件 ' . $file);
                                    }
                                } else $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法创建目录：' . $folderName);
                            } else $operationLogNcoe[] = array('type' => 'info', 'msg' => '目录已存在：' . $folderName . '，跳过自动创建');
                        }
                    }
                }
                closedir($dirHandle);
                if (!empty($autoCreatedFolders)) $operationLogNcoe[] = array('type' => 'success', 'msg' => '自动创建了 ' . count($autoCreatedFolders) . ' 个目录：' . implode(', ', $autoCreatedFolders));
                else $operationLogNcoe[] = array('type' => 'info', 'msg' => '未找到符合格式的HTML文件需要自动创建目录');
            }
            $operationLogNcoe[] = array('type' => 'title', 'msg' => '开始检测域名解析状态');
            $domainStatus = array(); $sampleDomain = '';
            foreach ($matchedFolders as $folder => $subdomain) {
                $dnsInfo = checkDomainDNS($subdomain);
                $domainStatus[$subdomain] = $dnsInfo;
                if (empty($sampleDomain) && (!empty($dnsInfo['ip']) || !empty($dnsInfo['cname']))) $sampleDomain = $subdomain;
                if (!empty($dnsInfo['ip'])) $operationLogNcoe[] = array('type' => 'success', 'msg' => '【' . $subdomain . '】：解析到IP ' . implode(', ', $dnsInfo['ip']));
                if (!empty($dnsInfo['cname'])) $operationLogNcoe[] = array('type' => 'success', 'msg' => '【' . $subdomain . '】：CNAME指向 ' . implode(', ', $dnsInfo['cname']));
                if (!empty($dnsInfo['error'])) $operationLogNcoe[] = array('type' => 'warning', 'msg' => '【' . $subdomain . '】：' . $dnsInfo['error']);
            }
            $operationLogNcoe[] = array('type' => 'title', 'msg' => '开始重命名HTML文件');
            $renameLog = array();
            foreach ($matchedFolders as $folder => $domain) {
                $targetDir = $currentDir . DIRECTORY_SEPARATOR . $folder;
                $subDirHandle = opendir($targetDir);
                if (!$subDirHandle) { $operationLogNcoe[] = array('type' => 'warning', 'msg' => '无法访问文件夹【' . $folder . '】，跳过该目录的HTML重命名'); $renameLog[$folder] = '无法访问目录，跳过处理'; continue; }
                $htmlFiles = array();
                while (($subFile = readdir($subDirHandle)) !== false) {
                    $subFilePath = $targetDir . DIRECTORY_SEPARATOR . $subFile;
                    if (is_dir($subFilePath)) continue;
                    $fileExt = strtolower(pathinfo($subFile, PATHINFO_EXTENSION));
                    if (in_array($fileExt, $htmlExt)) $htmlFiles[] = $subFile;
                }
                closedir($subDirHandle);
                if (empty($htmlFiles)) { $operationLogNcoe[] = array('type' => 'info', 'msg' => '【' . $folder . '】：无HTML/HTM文件，无需处理'); $renameLog[$folder] = '无HTML/HTM文件，无需处理'; continue; }
                $renameCount = 0; $skipCount = 0;
                foreach ($htmlFiles as $htmlFile) {
                    $oldPath = $targetDir . DIRECTORY_SEPARATOR . $htmlFile;
                    $newPath = $targetDir . DIRECTORY_SEPARATOR . 'index.html';
                    if (file_exists($newPath)) { $operationLogNcoe[] = array('type' => 'warning', 'msg' => '【' . $folder . '】：index.html 已存在，跳过文件 ' . $htmlFile); $skipCount++; continue; }
                    if ($htmlFile != 'index.html') {
                        if (rename($oldPath, $newPath)) { $renameCount++; $operationLogNcoe[] = array('type' => 'success', 'msg' => '【' . $folder . '】：' . $htmlFile . ' → index.html'); }
                        else $operationLogNcoe[] = array('type' => 'error', 'msg' => '【' . $folder . '】：无法重命名' . $htmlFile);
                    }
                }
                $logMsg = '成功重命名' . $renameCount . '个文件'; if ($skipCount > 0) $logMsg .= '，跳过' . $skipCount . '个文件（index.html已存在）';
                $renameLog[$folder] = $logMsg;
            }
            $operationLogNcoe[] = array('type' => 'title', 'msg' => '重命名汇总');
            foreach ($renameLog as $folder => $msg) $operationLogNcoe[] = array('type' => 'list', 'msg' => '【' . $folder . '】：' . $msg);
            $operationLogNcoe[] = array('type' => 'title', 'msg' => '开始处理.htaccess规则');
            $existingContent = '';
            if (file_exists($htaccessPath)) {
                $existingContent = file_get_contents($htaccessPath);
                if (strpos($existingContent, $rewriteEngineMark) === false) { $existingContent = $rewriteEngineMark . "\n\n" . $existingContent; $operationLogNcoe[] = array('type' => 'info', 'msg' => '已为.htaccess添加RewriteEngine On'); }
                else { $lines = explode("\n", $existingContent); $hasRewriteEngine = false; $newLines = array(); $newLines[] = $rewriteEngineMark; foreach ($lines as $line) { $trimmedLine = trim($line); if ($trimmedLine === $rewriteEngineMark) { $hasRewriteEngine = true; continue; } if (!empty($trimmedLine)) $newLines[] = $line; } $existingContent = implode("\n", $newLines); if ($hasRewriteEngine) $operationLogNcoe[] = array('type' => 'info', 'msg' => '已调整.htaccess结构，确保RewriteEngine On在第一行'); }
            } else { $existingContent = $rewriteEngineMark . "\n\n"; $operationLogNcoe[] = array('type' => 'info', 'msg' => '创建新的.htaccess文件并添加RewriteEngine On'); }
            $newRules = ''; $specialDomains = array();
            foreach ($matchedFolders as $folder => $subdomain) {
                // 检测四段式文件夹（www开头）特殊处理顶级域名
                if (preg_match('/^www-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)-([a-zA-Z0-9]+)$/', $folder, $matches)) {
                    $domainName = $matches[1] . '.' . $matches[2];
                    $tld = $matches[3];
                    $wwwDomain = 'www.' . $domainName . '.' . $tld;
                    $rootDomain = $domainName . '.' . $tld;
                    $operationLogNcoe[] = array('type' => 'info', 'msg' => '检测到四段顶级域名格式：' . $folder);
                    $operationLogNcoe[] = array('type' => 'info', 'msg' => '将同时绑定：' . $wwwDomain . ' 和 ' . $rootDomain);
                    $wwwRuleCheck = 'RewriteCond %{HTTP_HOST} ^' . $wwwDomain . '$ [NC]';
                    $rootRuleCheck = 'RewriteCond %{HTTP_HOST} ^' . $rootDomain . '$ [NC]';
                    $wwwExists = (strpos($existingContent, $wwwRuleCheck) !== false);
                    $rootExists = (strpos($existingContent, $rootRuleCheck) !== false);
                    if (!$wwwExists) { $newRule = "# 绑定 " . $wwwDomain . " 到 /" . $folder . "/ 目录\nRewriteCond %{HTTP_HOST} ^" . $wwwDomain . "$ [NC]\nRewriteCond %{REQUEST_URI} !^/" . $folder . "/\nRewriteRule ^(.*)$ /" . $folder . "/$1 [L]\n\n"; $newRules .= $newRule; $operationLogNcoe[] = array('type' => 'success', 'msg' => '生成【' . $wwwDomain . ' → ' . $folder . '】规则'); }
                    else $operationLogNcoe[] = array('type' => 'info', 'msg' => '【' . $wwwDomain . '】规则已存在，跳过');
                    if (!$rootExists) { $newRule = "# 绑定 " . $rootDomain . " 并301跳转到 " . $wwwDomain . "\nRewriteCond %{HTTP_HOST} ^" . $rootDomain . "$ [NC]\nRewriteRule ^(.*)$ http://" . $wwwDomain . "/$1 [L,R=301]\n\n"; $newRules .= $newRule; $operationLogNcoe[] = array('type' => 'success', 'msg' => '生成【' . $rootDomain . ' → 301跳转 → ' . $wwwDomain . '】规则'); }
                    else $operationLogNcoe[] = array('type' => 'info', 'msg' => '【' . $rootDomain . '】规则已存在，跳过');
                    $specialDomains[] = $folder; continue;
                }
                // 普通子域名处理（包括三段式和四段式中的非顶级域名）
                $ruleCheck = 'RewriteCond %{HTTP_HOST} ^' . $subdomain . '$ [NC]';
                if (strpos($existingContent, $ruleCheck) !== false) { $operationLogNcoe[] = array('type' => 'info', 'msg' => '【' . $subdomain . '】规则已存在，跳过'); continue; }
                $newRule = "# 绑定 " . $subdomain . " 到 /" . $folder . "/ 目录\nRewriteCond %{HTTP_HOST} ^" . $subdomain . "$ [NC]\nRewriteCond %{REQUEST_URI} !^/" . $folder . "/\nRewriteRule ^(.*)$ /" . $folder . "/$1 [L]\n\n";
                $newRules .= $newRule; $operationLogNcoe[] = array('type' => 'success', 'msg' => '生成【' . $subdomain . ' → ' . $folder . '】规则');
            }
            if (!empty($newRules)) {
                $finalContent = $existingContent;
                if (strpos($finalContent, $rewriteEngineMark) !== 0) { $lines = explode("\n", $finalContent); $hasRewriteEngine = false; $otherLines = array(); foreach ($lines as $line) { $trimmedLine = trim($line); if ($trimmedLine === $rewriteEngineMark) { $hasRewriteEngine = true; continue; } if (!empty($trimmedLine)) $otherLines[] = $line; } $finalContent = $rewriteEngineMark . "\n\n" . implode("\n", $otherLines); if (!$hasRewriteEngine) $finalContent = $rewriteEngineMark . "\n\n" . $finalContent; }
                $finalContent .= $newRules;
                if (file_put_contents($htaccessPath, $finalContent)) { $ruleNum = substr_count($newRules, 'RewriteCond %{HTTP_HOST}'); $redirectNum = substr_count($newRules, 'R=301'); $operationLogNcoe[] = array('type' => 'success', 'msg' => '成功写入 ' . $ruleNum . ' 条规则到.htaccess（包含 ' . $redirectNum . ' 条301跳转）'); $operationLogNcoe[] = array('type' => 'info', 'msg' => '已确保.htaccess第一行为RewriteEngine On'); }
                else $operationLogNcoe[] = array('type' => 'error', 'msg' => '无法写入.htaccess');
            } else { $operationLogNcoe[] = array('type' => 'info', 'msg' => '所有子域名规则均已存在，无需新增'); if (strpos($existingContent, $rewriteEngineMark) === false) { $finalContent = $rewriteEngineMark . "\n\n" . $existingContent; if (file_put_contents($htaccessPath, $finalContent)) $operationLogNcoe[] = array('type' => 'info', 'msg' => '已确保.htaccess包含RewriteEngine On'); } }
            $operationLogNcoe[] = array('type' => 'title', 'msg' => '操作完成');
            $resolutionHint = '';
            if (!empty($sampleDomain)) { $sampleDNS = $domainStatus[$sampleDomain]; if (!empty($sampleDNS['ip'])) $resolutionHint = 'IP地址：' . implode(', ', $sampleDNS['ip']); elseif (!empty($sampleDNS['cname'])) $resolutionHint = 'CNAME记录：' . implode(', ', $sampleDNS['cname']); }
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '1. 请确认子域名已正确解析（如' . ($sampleDomain ?: 'w01.cdswcy.cn') . ' → ' . ($resolutionHint ?: '目标服务器') . '）');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '2. 请确认Apache已启用mod_rewrite模块，且AllowOverride设为All');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '3. 已自动处理主目录下符合格式的HTML文件：创建对应文件夹并移动文件为index.html');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '4. 目标目录内HTML已统一为index.html（如index.html已存在则跳过）');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '5. 检测到 ' . count($specialDomains) . ' 个顶级域名，已自动设置www和根域名绑定');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '6. 已确保.htaccess第一行为RewriteEngine On，这是Apache重写规则的必要条件');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '7. 如需生成SEO链接页面，请点击"生成SEO页面"按钮');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '8. 支持上传ZIP压缩包自动解压到当前目录');
            $operationLogNcoe[] = array('type' => 'notice', 'msg' => '9. 后续新增符合格式的文件夹或HTML文件，重新运行本系统即可自动处理');
        }
    }
}

// ==================== 备份管理模块数据准备 ====================
if ($showBackup) {
    $backupScanResult = scanDirectories($target_files);
}

// ==================== HTML 输出 ====================
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>舜王站群综合管理系统 - 成都舜王科技有限公司</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: "Microsoft YaHei", Arial, sans-serif; font-size: 14px; line-height: 1.6; color: #333; background-color: #f5f7fa; }
        .container { width: 95%; max-width: 1400px; margin: 20px auto; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden; }
        .header { background-color: #2c5282; color: #fff; padding: 20px 30px; }
        .header h1 { font-size: 24px; font-weight: normal; }
        .header p { margin-top: 8px; opacity: 0.9; }
        .nav-tabs { background: #edf2f7; border-bottom: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; padding: 0 20px; }
        .nav-tabs a { padding: 12px 20px; text-decoration: none; color: #4a5568; font-weight: 500; border-bottom: 3px solid transparent; transition: all 0.2s; }
        .nav-tabs a:hover { background: #e2e8f0; }
        .nav-tabs a.active { color: #2c5282; border-bottom-color: #2c5282; background: white; }
        .content { padding: 25px; }
        .footer { padding: 20px 30px; border-top: 1px solid #e2e8f0; text-align: center; color: #718096; }

        /* 通用组件 */
        .btn { background-color: #3182ce; color: #fff; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 12px; }
        .btn:hover { background-color: #2b6cb0; }
        .btn-success { background-color: #38a169; }
        .btn-success:hover { background-color: #2f855a; }
        .btn-warning { background-color: #ed8936; }
        .btn-warning:hover { background-color: #dd771c; }
        .btn-danger { background-color: #e53e3e; }
        .btn-danger:hover { background-color: #c53030; }
        .btn-info { background-color: #4299e1; }
        .btn-info:hover { background-color: #3182ce; }
        .btn-purple { background-color: #805ad5; }
        .btn-purple:hover { background-color: #6b46c1; }
        .btn-teal { background-color: #319795; }
        .btn-teal:hover { background-color: #2c7a7b; }
        .btn-gray { background-color: #718096; }
        .btn-gray:hover { background-color: #4a5568; }
        .btn-orange { background-color: #ed8936; }
        .btn-orange:hover { background-color: #dd771c; }
        .btn-pink { background-color: #d53f8c; }
        .btn-pink:hover { background-color: #b83280; }
        .btn-cyan { background-color: #0bc5ea; }
        .btn-cyan:hover { background-color: #00b5d8; }

        .form-group { margin-bottom: 15px; }
        .form-label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-input, .form-textarea, .form-select { width: 100%; padding: 8px 12px; border: 1px solid #cbd5e0; border-radius: 4px; font-size: 14px; }
        .form-textarea { height: 300px; font-family: monospace; resize: vertical; }
        .form-actions { display: flex; gap: 10px; margin-top: 15px; flex-wrap: wrap; }

        .log-section { border: 1px solid #e2e8f0; border-radius: 4px; overflow: hidden; margin-bottom: 20px; }
        .log-header { background-color: #edf2f7; padding: 12px 15px; border-bottom: 1px solid #e2e8f0; font-weight: bold; }
        .log-list { padding: 15px; max-height: 400px; overflow-y: auto; background-color: #fefefe; }
        .log-item { margin-bottom: 10px; padding: 8px 12px; border-radius: 4px; word-break: break-all; }
        .log-item.success { background-color: #f0fff4; border-left: 4px solid #48bb78; color: #22543d; }
        .log-item.error { background-color: #fff5f5; border-left: 4px solid #f56565; color: #742a2a; }
        .log-item.warning { background-color: #fffaf0; border-left: 4px solid #ed8936; color: #744210; }
        .log-item.info { background-color: #edf2fc; border-left: 4px solid #63b3ed; color: #2c5282; }
        .log-item.title { background-color: #f7fafc; border-left: 4px solid #805ad5; color: #4a5568; font-weight: bold; margin-top: 15px; }
        .log-item.notice { background-color: #f7fafc; border-left: 4px solid #3182ce; color: #2c5282; }
        .log-item.list { background-color: #fefefe; border-left: 4px solid #cbd5e0; color: #4a5568; padding-left: 18px; }

        .file-list { border: 1px solid #e2e8f0; border-radius: 4px; overflow: hidden; margin-bottom: 20px; }
        .file-header { background-color: #edf2f7; padding: 12px 15px; border-bottom: 1px solid #e2e8f0; font-weight: bold; display: grid; grid-template-columns: 40% 20% 20% 20%; }
        .file-item { display: grid; grid-template-columns: 40% 20% 20% 20%; padding: 10px 15px; border-bottom: 1px solid #e2e8f0; align-items: center; }
        .file-item:hover { background-color: #f8fafc; }
        .file-actions { display: flex; gap: 8px; flex-wrap: wrap; }
        .sub-directory { margin-left: 30px; border: 1px solid #e2e8f0; border-radius: 4px; margin-top: 10px; }
        .edit-form, .create-form, .batch-replace-form, .friend-links-form, .dns-manager-form, .ncoe-manager-form, .backup-form { background: #f8fafc; padding: 20px; border-radius: 4px; border: 1px solid #e2e8f0; margin-bottom: 20px; }
        .function-block { padding: 15px; border-radius: 4px; margin-bottom: 20px; }
        .function-title { margin-bottom: 10px; font-size: 16px; font-weight: bold; }
        .result-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 15px; }
        .result-box { padding: 10px; border-radius: 4px; max-height: 200px; overflow-y: auto; }
        .result-success { background: #f0fff4; border: 1px solid #9ae6b4; }
        .result-warning { background: #fff5f5; border: 1px solid #fed7d7; }
        .friend-link-function { display: none; margin-top: 15px; }
        .friend-link-function.active { display: block; }
        .help-content { display: none; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 15px; margin-top: 15px; }

        @media (max-width: 768px) {
            .file-header, .file-item { grid-template-columns: 1fr; gap: 5px; }
            .nav-tabs a { padding: 8px 12px; font-size: 12px; }
            .result-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>舜王站群综合管理系统</h1>
        <p>站群配置 | 文件管理 | 友情链接 | 批量替换 | DNSPod解析 | 备份管理 | 自删除</p>
    </div>

    <div class="nav-tabs">
        <a href="?" class="<?php echo (!$showFriendLinks && !$showBatchReplace && !$showDnsManager && !$showBackup && !$showNcoe) ? 'active' : ''; ?>">文件管理</a>
        <a href="?ncoe=1" class="<?php echo $showNcoe ? 'active' : ''; ?>">站群配置</a>
        <a href="?friend_links=1" class="<?php echo $showFriendLinks ? 'active' : ''; ?>">友情链接</a>
        <a href="?batch_replace=1" class="<?php echo $showBatchReplace ? 'active' : ''; ?>">批量替换</a>
        <a href="?dns_manager=1" class="<?php echo $showDnsManager ? 'active' : ''; ?>">DNSPod解析</a>
        <a href="?backup=1" class="<?php echo $showBackup ? 'active' : ''; ?>">备份管理</a>
    </div>

    <div class="content">
        <!-- ==================== 文件管理模块 ==================== -->
        <?php if (!$showFriendLinks && !$showBatchReplace && !$showDnsManager && !$showBackup && !$showNcoe): ?>
            <!-- 顶部快捷按钮 -->
            <div style="margin-bottom: 15px; display: flex; gap: 10px; flex-wrap: wrap;">
                <form method="post" style="display: inline;">
                    <button type="submit" name="download_ico" class="btn btn-teal" onclick="return confirm('确定要从 https://seo.ncoe.cn/favicon.ico 下载并植入ICO图标到所有三段式文件夹吗？')">植入ICO图标</button>
                </form>
            </div>

            <!-- 文件编辑表单 -->
            <?php if ($editingFile): ?>
            <div class="edit-form">
                <h4>编辑文件：<?php echo htmlspecialchars(getRelativePath($editingFile, $currentDir)); ?></h4>
                <p>访问地址：<a href="<?php echo getFileDomainUrl($editingFile, $currentDir); ?>" target="_blank"><?php echo getFileDomainUrl($editingFile, $currentDir); ?></a></p>
                <form method="post">
                    <input type="hidden" name="file_path" value="<?php echo htmlspecialchars($editingFile); ?>">
                    <div class="form-group">
                        <label class="form-label">文件内容：</label>
                        <textarea name="file_content" class="form-textarea"><?php echo $fileContent; ?></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="save_file" class="btn">保存文件</button>
                        <a href="?" class="btn btn-warning">取消编辑</a>
                    </div>
                </form>
            </div>
            <?php endif; ?>

            <!-- 创建文件表单 -->
            <?php if ($creatingFile): ?>
            <div class="create-form">
                <h4>创建新文件/文件夹</h4>
                <form method="post">
                    <div class="form-group">
                        <label class="form-label">路径：</label>
                        <input type="text" name="new_file_path" class="form-input" value="<?php echo htmlspecialchars($creatingFile); ?>">
                        <small>无后缀则创建文件夹，有后缀则创建文件</small>
                    </div>
                    <div class="form-group">
                        <label class="form-label">文件内容（仅文件有效）：</label>
                        <textarea name="new_file_content" class="form-textarea"></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="create_file" class="btn btn-success">创建</button>
                        <a href="?" class="btn btn-warning">取消</a>
                    </div>
                </form>
            </div>
            <?php endif; ?>

            <!-- 文件列表 -->
            <div class="file-list">
                <div class="file-header">
                    <div>文件名</div>
                    <div>大小</div>
                    <div>修改时间</div>
                    <div>操作</div>
                </div>
                <?php foreach ($fileList as $file): ?>
                <div class="file-item">
                    <div class="file-name">
                        <span><?php echo $file['is_dir'] ? '📁' : '📄'; ?></span>
                        <?php echo htmlspecialchars($file['name']); ?>
                    </div>
                    <div><?php echo $file['size']; ?></div>
                    <div><?php echo $file['modified']; ?></div>
                    <div class="file-actions">
                        <?php if ($file['is_dir']): ?>
                            <?php if ($expandedDir == $file['path']): ?>
                                <a href="?" class="btn btn-small">收起</a>
                            <?php else: ?>
                                <a href="?expand=<?php echo urlencode($file['path']); ?>" class="btn btn-small">展开</a>
                            <?php endif; ?>
                            <a href="<?php echo getFileDomainUrl($file['path'], $currentDir); ?>" target="_blank" class="btn btn-small btn-success">查看</a>
                            <a href="?create=<?php echo urlencode($file['path'] . DIRECTORY_SEPARATOR . 'index.html'); ?>" class="btn btn-small btn-success">新建文件</a>
                        <?php else: ?>
                            <?php if ($file['name'] != '.htaccess' && $file['name'] != 'favicon.ico'): ?>
                                <a href="?edit=<?php echo urlencode($file['path']); ?>" class="btn btn-small">编辑</a>
                            <?php else: ?>
                                <span class="btn btn-small btn-disabled">编辑</span>
                            <?php endif; ?>
                            <?php if ($file['name'] != '.htaccess'): ?>
                                <a href="<?php echo getFileDomainUrl($file['path'], $currentDir); ?>" target="_blank" class="btn btn-small btn-success">查看</a>
                            <?php else: ?>
                                <span class="btn btn-small btn-disabled">查看</span>
                            <?php endif; ?>
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="file_path" value="<?php echo htmlspecialchars($file['path']); ?>">
                                <button type="submit" name="delete_file" class="btn btn-small btn-danger" onclick="return confirm('确定删除？')">删除</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ($file['is_dir'] && $expandedDir == $file['path']): ?>
                <div class="sub-directory">
                    <?php foreach ($expandedFiles as $subFile): ?>
                    <div class="file-item">
                        <div class="file-name">📄 <?php echo htmlspecialchars($subFile['name']); ?></div>
                        <div><?php echo $subFile['size']; ?></div>
                        <div><?php echo $subFile['modified']; ?></div>
                        <div class="file-actions">
                            <?php if ($subFile['name'] != '.htaccess' && $subFile['name'] != 'favicon.ico'): ?>
                                <a href="?edit=<?php echo urlencode($subFile['path']); ?>" class="btn btn-small">编辑</a>
                            <?php else: ?>
                                <span class="btn btn-small btn-disabled">编辑</span>
                            <?php endif; ?>
                            <a href="<?php echo getFileDomainUrl($subFile['path'], $currentDir); ?>" target="_blank" class="btn btn-small btn-success">查看</a>
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="file_path" value="<?php echo htmlspecialchars($subFile['path']); ?>">
                                <button type="submit" name="delete_file" class="btn btn-small btn-danger" onclick="return confirm('确定删除？')">删除</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php if (empty($expandedFiles)): ?><div class="file-item"><div style="grid-column:1/-1;text-align:center;color:#718096;padding:20px;">空目录</div></div><?php endif; ?>
                </div>
                <?php endif; ?>
                <?php endforeach; ?>
                <?php if (empty($fileList)): ?><div class="file-item"><div style="grid-column:1/-1;text-align:center;color:#718096;padding:20px;">没有找到三段目录或特定文件</div></div><?php endif; ?>
            </div>

            <!-- 操作日志 -->
            <?php if ($isExecuted && !empty($operationLog)): ?>
            <div class="log-section">
                <div class="log-header">操作日志</div>
                <div class="log-list">
                    <?php foreach ($operationLog as $log): ?>
                        <div class="log-item <?php echo $log['type']; ?>"><?php echo htmlspecialchars($log['msg']); ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- ==================== 站群配置模块 ==================== -->
        <?php if ($showNcoe): ?>
        <div class="ncoe-manager-form">
            <h4>站群域名分配系统</h4>
            <div style="margin-bottom: 15px; display: flex; gap: 10px; flex-wrap: wrap;">
                <form method="post" enctype="multipart/form-data" style="display: flex; gap: 10px; align-items: center;">
                    <input type="file" name="zipfile" accept=".zip" required>
                    <button type="submit" class="btn">上传并解压ZIP</button>
                </form>
                <form method="post" style="display: inline;"><button type="submit" name="execute" class="btn btn-success">开始执行站群配置</button></form>
                <form method="post" style="display: inline;"><button type="submit" name="generate_seo" class="btn btn-info">生成SEO页面</button></form>
            </div>
            <?php if ($isExecutedNcoe && !empty($operationLogNcoe)): ?>
            <div class="log-section">
                <div class="log-header">操作日志</div>
                <div class="log-list">
                    <?php foreach ($operationLogNcoe as $log): ?>
                        <?php if ($log['type'] == 'notice') { echo '<div class="log-item notice">' . $log['msg'] . '</div>'; } else { echo '<div class="log-item ' . $log['type'] . '">' . htmlspecialchars($log['msg']) . '</div>'; } ?>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="log-section"><div class="log-header">操作说明</div><div class="log-list"><div class="log-item info">1. 上传ZIP压缩包解压到当前目录</div><div class="log-item info">2. 点击“开始执行站群配置”自动处理文件夹、HTML重命名、生成.htaccess规则</div><div class="log-item info">3. 点击“生成SEO页面”创建链接导航（关键词稳定）</div><div class="log-item info">支持顶级域名格式（www-xxx-cn）自动设置www和根域名301跳转</div><div class="log-item info">支持四段式文件夹（www-xxx-xxx-xxx）自动绑定为 www.xxx.xxx.xxx</div></div></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- ==================== 友情链接管理模块 ==================== -->
        <?php if ($showFriendLinks): ?>
        <div class="friend-links-form">
            <h4>友情链接管理</h4>
            <div style="margin-bottom: 15px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button type="button" class="btn btn-pink" onclick="toggleFriendFunction('shuffle')">打乱链接顺序</button>
                <button type="button" class="btn btn-info" onclick="toggleFriendFunction('detect')">检测矩阵</button>
                <button type="button" class="btn btn-warning" onclick="toggleFriendFunction('search')">查找链接</button>
                <button type="button" class="btn btn-danger" onclick="toggleFriendFunction('delete')">批量删除</button>
                <button type="button" class="btn btn-purple" onclick="toggleFriendFunction('smart')">智能替换</button>
                <button type="button" class="btn btn-teal" id="showHelpBtn">📘 使用说明</button>
            </div>

            <!-- 帮助内容区域（内联，不弹出新页面） -->
            <div id="helpContent" class="help-content" style="display:none;">
                <div class="log-header" style="margin-bottom:10px;">📘 友情链接矩阵使用说明</div>
                <div class="log-list">
                    <div class="log-item info">1. 在您的HTML文件中，使用以下标记包裹友情链接区域：</div>
                    <div class="log-item list"><code>&lt;!-- 友情链接矩阵开始 --&gt;</code><br><code>&lt;a href="http://example.com" target="_blank"&gt;链接文字&lt;/a&gt;</code><br><code>&lt;!-- 友情链接矩阵结束 --&gt;</code></div>
                    <div class="log-item info">2. 标记内的所有链接将作为友情链接矩阵内容，系统会自动识别并支持批量替换、打乱顺序等操作。</div>
                    <div class="log-item info">3. 如果您还没有添加这些标记，请手动在index.html中添加。</div>
                    <div class="log-item info">4. 本工具的所有友情链接功能（替换、打乱、删除、智能替换）均基于这两个标记之间的内容进行操作。</div>
                    <div class="log-item warning">提示：使用说明可再次点击上方按钮关闭。</div>
                </div>
            </div>

            <div id="shuffle-function" class="friend-link-function active">
                <div class="function-block"><div class="function-title">🎲 打乱友情链接</div><form method="post"><button type="submit" name="shuffle_friend_links" class="btn btn-pink" onclick="return confirm('确定打乱所有友情链接顺序？')">执行打乱</button></form></div>
            </div>
            <div id="detect-function" class="friend-link-function">
                <div class="function-block"><div class="function-title">🔍 检测矩阵</div><form method="post"><button type="submit" name="detect_friend_links" class="btn btn-info">检测</button></form>
                <?php if (isset($_SESSION['matrix_files']) || isset($_SESSION['no_matrix_files'])): ?>
                <div class="result-grid">
                    <div class="result-box result-success"><strong>✅ 有矩阵 (<?php echo count($_SESSION['matrix_files']); ?>)</strong><br><?php foreach ($_SESSION['matrix_files'] as $f): ?><div><a href="<?php echo $f['domain']; ?>" target="_blank"><?php echo $f['file']; ?></a></div><?php endforeach; ?></div>
                    <div class="result-box result-warning"><strong>❌ 无矩阵 (<?php echo count($_SESSION['no_matrix_files']); ?>)</strong><br><?php foreach ($_SESSION['no_matrix_files'] as $f): ?><div><a href="<?php echo $f['domain']; ?>" target="_blank"><?php echo $f['file']; ?></a></div><?php endforeach; ?></div>
                </div>
                <?php endif; ?>
                </div>
            </div>
            <div id="search-function" class="friend-link-function">
                <div class="function-block"><div class="function-title">📋 查找链接</div><form method="post"><input type="text" name="search_code" class="form-input" placeholder="输入完整链接HTML代码" required><button type="submit" name="friend_links_search" class="btn btn-warning">查找</button></form>
                <?php if (isset($_SESSION['found_links'])): ?><div><strong>找到 <?php echo count($_SESSION['found_links']); ?> 个文件：</strong><?php foreach ($_SESSION['found_links'] as $l): ?><div><a href="<?php echo $l['domain']; ?>" target="_blank"><?php echo $l['file']; ?></a></div><?php endforeach; ?></div><?php endif; ?>
                </div>
            </div>
            <div id="delete-function" class="friend-link-function">
                <div class="function-block"><div class="function-title">🗑️ 批量删除</div><form method="post"><input type="text" name="delete_code" class="form-input" placeholder="要删除的链接代码" required><select name="delete_mode" class="form-select"><option value="link_only">仅删除链接</option><option value="whole_div">删除整个div（保留标记）</option></select><button type="submit" name="friend_links_batch_delete" class="btn btn-danger" onclick="return confirm('确定删除？')">删除</button></form></div>
            </div>
            <div id="smart-function" class="friend-link-function">
                <div class="function-block"><div class="function-title">🔄 智能替换</div><form method="post"><input type="text" name="link_code" class="form-input" placeholder="要查找的链接代码" required><button type="submit" name="friend_links_smart_replace" class="btn btn-purple" onclick="return confirm('确定替换包含该链接的div内部内容？')">智能替换</button></form></div>
            </div>

            <!-- 批量替换友情链接内容（固定显示） -->
            <div class="function-block" style="background:#c6f6d5; border-color:#9ae6b4;">
                <div class="function-title">📝 批量替换友情链接内容（矩阵标记内）</div>
                <form method="post">
                    <textarea name="friend_links_content" class="form-textarea" placeholder="输入新友情链接HTML代码" style="height:200px;"></textarea>
                    <div class="form-actions">
                        <button type="submit" name="friend_links_replace" value="replace_all" class="btn btn-warning" onclick="document.getElementById('replace_type').value='replace_all'">全部替换</button>
                        <button type="submit" name="friend_links_replace" value="add_to_begin" class="btn btn-success" onclick="document.getElementById('replace_type').value='add_to_begin'">增加到前列</button>
                        <button type="submit" name="friend_links_replace" value="add_to_end" class="btn btn-info" onclick="document.getElementById('replace_type').value='add_to_end'">增加到结尾</button>
                    </div>
                    <input type="hidden" name="replace_type" id="replace_type" value="">
                </form>
            </div>

            <?php if ($isExecuted && !empty($operationLog)): ?>
            <div class="log-section"><div class="log-header">操作日志</div><div class="log-list"><?php foreach ($operationLog as $log): ?><div class="log-item <?php echo $log['type']; ?>"><?php echo htmlspecialchars($log['msg']); ?></div><?php endforeach; ?></div></div>
            <?php endif; ?>
        </div>
        <script>
        function toggleFriendFunction(type){
            var funcs=['shuffle','detect','search','delete','smart'];
            funcs.forEach(function(f){document.getElementById(f+'-function').classList.remove('active');});
            document.getElementById(type+'-function').classList.add('active');
        }
        document.getElementById('showHelpBtn').onclick = function(){
            var helpDiv = document.getElementById('helpContent');
            if(helpDiv.style.display === 'none' || helpDiv.style.display === ''){
                helpDiv.style.display = 'block';
            } else {
                helpDiv.style.display = 'none';
            }
        };
        </script>
        <?php endif; ?>

        <!-- ==================== 批量替换模块 ==================== -->
        <?php if ($showBatchReplace): ?>
        <div class="batch-replace-form">
            <h4>批量替换 - 三段式/四段式文件夹内HTML文件</h4>
            <form method="post">
                <div class="form-group"><label class="form-label">查找文本：</label><textarea name="search_text" class="form-textarea" required></textarea></div>
                <div class="form-group"><label class="form-label">替换文本：</label><textarea name="replace_text" class="form-textarea"></textarea></div>
                <div class="form-actions">
                    <button type="submit" name="batch_replace" class="btn btn-warning" onclick="return confirm('确定执行批量替换？')">执行替换</button>
                    <button type="submit" name="replace_https" class="btn btn-purple" onclick="return confirm('确定将http://img和https://img替换为//img？')">替换HTTPS</button>
                    <a href="?" class="btn">返回</a>
                </div>
            </form>
            <?php if ($isExecuted && !empty($operationLog)): ?>
            <div class="log-section"><div class="log-header">操作日志</div><div class="log-list"><?php foreach ($operationLog as $log): ?><div class="log-item <?php echo $log['type']; ?>"><?php echo htmlspecialchars($log['msg']); ?></div><?php endforeach; ?></div></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- ==================== DNSPod管理模块 ==================== -->
        <?php if ($showDnsManager): ?>
        <div class="dns-manager-form">
            <h4>DNSPod域名解析同步</h4>
            <?php if ($dnsMessage): ?><div class="log-item <?php echo $dnsMessageType; ?>" style="margin-bottom:15px;"><?php echo htmlspecialchars($dnsMessage); ?></div><?php endif; ?>
            <?php if (!empty($detectedFolders)): ?>
            <form method="post" id="fullSyncForm">
                <input type="hidden" name="action" value="full_sync">
                <div style="display:flex; gap:10px; margin-bottom:20px;">
                    <div style="flex:1;"><label class="form-label">目标CNAME地址：</label><input type="text" name="target_cname" class="form-input" value="<?php echo htmlspecialchars($currentCname ?: ''); ?>" required></div>
                    <div><button type="submit" class="btn btn-success" style="margin-top:24px;">一键同步解析 (<?php echo count($detectedFolders); ?>个域名)</button></div>
                </div>
            </form>
            <div class="file-list"><div class="file-header"><div>文件夹</div><div>前缀</div><div>域名</div><div>完整域名</div></div>
            <?php foreach ($detectedFolders as $f): ?><div class="file-item"><div><?php echo $f['folder']; ?></div><div><?php echo $f['prefix']; ?></div><div><?php echo $f['domain'].'.'.$f['tld']; ?></div><div><?php echo $f['full_domain']; ?></div></div><?php endforeach; ?>
            </div>
            <?php else: ?><p>未检测到三段式或四段式文件夹</p><?php endif; ?>
            <?php if (!empty($fullSyncResults)): ?>
            <div><h4>同步结果</h4><div class="file-list"><div class="file-header"><div>域名</div><div>状态</div><div>详情</div></div>
            <?php foreach ($fullSyncResults['results'] as $domain => $res): ?><div class="file-item"><div><?php echo $domain; ?></div><div><?php if($res['status']=='success') echo '✓成功'; elseif($res['status']=='error') echo '✗失败'; else echo '⚠部分成功'; ?></div><div><?php echo $res['message']; ?></div></div><?php endforeach; ?>
            </div></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- ==================== 备份管理模块 ==================== -->
        <?php if ($showBackup): ?>
        <div class="backup-form">
            <h4>备份管理（打包/清空/自删除）</h4>
            <!-- 操作结果区域放在最上方 -->
            <div class="log-section" id="backupResultLog" style="display:none;">
                <div class="log-header">操作结果</div>
                <div class="log-list" id="backupResultList"></div>
            </div>
            <div style="margin-bottom:15px; display:flex; gap:10px; flex-wrap:wrap;">
                <button type="button" class="btn btn-info" id="backupScanBtn">刷新列表</button>
                <button type="button" class="btn btn-purple" id="backupPackBtn">一键打包所有</button>
                <button type="button" class="btn btn-danger" id="backupClearBtn">一键清空所有</button>
                <button type="button" class="btn btn-pink" id="backupSelfDeleteBtn">创建自删除脚本</button>
                <?php if ($backupSelfDeleteExists): ?>
                <a href="delete_self.php" class="btn btn-warning" target="_blank">立即删除</a>
                <?php endif; ?>
            </div>
            <!-- 详细目录展示 -->
            <div class="file-list">
                <div class="file-header"><div>三段式/四段式文件夹</div><div>文件状态</div></div>
                <?php if (!empty($backupScanResult['folders'])): ?>
                    <?php foreach ($backupScanResult['folders'] as $folder): ?>
                    <div class="file-item">
                        <div><?php echo htmlspecialchars($folder['name']); ?></div>
                        <div><?php $cnt=0; foreach($folder['files'] as $exists){if($exists)$cnt++;} echo "$cnt/".count($target_files)." 个目标文件存在"; ?></div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="file-item"><div colspan="2">未检测到符合条件的文件夹</div></div>
                <?php endif; ?>
            </div>
            <div class="file-list">
                <div class="file-header"><div>目标文件</div></div>
                <?php if (!empty($backupScanResult['target_files'])): ?>
                    <?php foreach ($backupScanResult['target_files'] as $file): ?>
                    <div class="file-item"><div><?php echo htmlspecialchars($file); ?></div></div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="file-item"><div>未检测到目标文件</div></div>
                <?php endif; ?>
            </div>
            <div class="file-list">
                <div class="file-header"><div>ncoe压缩包</div><div>操作</div></div>
                <?php if (!empty($backupScanResult['ncoe_zips'])): ?>
                    <?php foreach ($backupScanResult['ncoe_zips'] as $zip): ?>
                    <div class="file-item">
                        <div><?php echo htmlspecialchars($zip); ?></div>
                        <div><a href="?download_zip=<?php echo urlencode($zip); ?>" class="btn btn-success btn-small">下载</a></div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="file-item"><div colspan="2">未检测到ncoe压缩包</div></div>
                <?php endif; ?>
            </div>
        </div>
        <script>
        (function() {
            let currentPackFile = '';
            function addLog(msg, type) {
                type = type || 'info';
                var logDiv = document.getElementById('backupResultList');
                if (!logDiv) return;
                var item = document.createElement('div');
                item.className = 'log-item ' + type;
                item.innerHTML = msg;
                logDiv.appendChild(item);
                document.getElementById('backupResultLog').style.display = 'block';
            }
            document.getElementById('backupScanBtn').onclick = function() { location.reload(); };
            document.getElementById('backupPackBtn').onclick = function() {
                var formData = new FormData();
                formData.append('action', 'pack');
                fetch('', { method: 'POST', body: formData })
                    .then(function(response) { return response.json(); })
                    .then(function(data) {
                        if (data.status === 'success') {
                            addLog('打包成功：' + data.filename, 'success');
                            currentPackFile = data.filename;
                            var downBtn = document.createElement('button');
                            downBtn.innerText = '下载打包文件';
                            downBtn.className = 'btn btn-success';
                            downBtn.style.marginRight = '10px';
                            downBtn.onclick = function() {
                                if (currentPackFile) {
                                    var f = document.createElement('form');
                                    f.method = 'POST';
                                    f.innerHTML = '<input type="hidden" name="action" value="download"><input type="hidden" name="filename" value="' + currentPackFile + '">';
                                    document.body.appendChild(f);
                                    f.submit();
                                }
                            };
                            var delBtn = document.createElement('button');
                            delBtn.innerText = '删除打包文件';
                            delBtn.className = 'btn btn-danger';
                            delBtn.onclick = function() {
                                if (currentPackFile && confirm('确定删除压缩包？')) {
                                    var fd = new FormData();
                                    fd.append('action', 'delete');
                                    fd.append('filename', currentPackFile);
                                    fetch('', { method: 'POST', body: fd })
                                        .then(function(r) { return r.json(); })
                                        .then(function(d2) {
                                            addLog(d2.message, d2.status);
                                            if (d2.status === 'success') currentPackFile = '';
                                        })
                                        .catch(function(e) { addLog('请求失败：' + e, 'error'); });
                                }
                            };
                            var btnContainer = document.getElementById('backupResultList');
                            btnContainer.appendChild(downBtn);
                            btnContainer.appendChild(delBtn);
                        } else {
                            addLog('打包失败：' + data.message, 'error');
                        }
                    })
                    .catch(function(e) { addLog('请求异常：' + e, 'error'); });
            };
            document.getElementById('backupClearBtn').onclick = function() {
                if (!confirm('⚠️ 警告：此操作将删除所有检测到的文件夹、目标文件和压缩包，不可逆！确定继续？')) return;
                var formData = new FormData();
                formData.append('action', 'clear_all');
                fetch('', { method: 'POST', body: formData })
                    .then(function(response) { return response.json(); })
                    .then(function(data) {
                        addLog(data.message, data.status === 'success' ? 'success' : 'error');
                        if (data.status === 'success') setTimeout(function() { location.reload(); }, 1500);
                    })
                    .catch(function(e) { addLog('请求异常：' + e, 'error'); });
            };
            document.getElementById('backupSelfDeleteBtn').onclick = function() {
                var formData = new FormData();
                formData.append('action', 'create_self_delete');
                fetch('', { method: 'POST', body: formData })
                    .then(function(response) { return response.json(); })
                    .then(function(data) {
                        addLog(data.message, data.success ? 'success' : 'error');
                        if (data.success && !document.getElementById('immediateDeleteBtn')) {
                            var btn = document.createElement('a');
                            btn.href = 'delete_self.php';
                            btn.className = 'btn btn-warning';
                            btn.innerText = '立即删除';
                            btn.target = '_blank';
                            document.getElementById('backupSelfDeleteBtn').parentNode.appendChild(btn);
                        }
                    })
                    .catch(function(e) { addLog('请求异常：' + e, 'error'); });
            };
        })();
        </script>
        <?php endif; ?>
    </div>

    <div class="footer">
        版权所有 © 成都舜王科技有限公司互联网事业部
    </div>
</div>
</body>
</html>